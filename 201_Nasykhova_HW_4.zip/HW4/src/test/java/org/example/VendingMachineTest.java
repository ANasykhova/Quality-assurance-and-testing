package org.example;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.junit.jupiter.params.provider.ValueSource;

import static org.junit.jupiter.api.Assertions.*;

class VendingMachineTest {

    private VendingMachine vm;
    static final long passcode = 117345294655382L;

    @BeforeEach
    void setUp() {
        vm = new VendingMachine();
    }

    // ...............................................
    // a
    @Test
    void getNumberOfProduct1() {
        assertEquals(VendingMachine.Mode.OPERATION, vm.getCurrentMode());
        assertEquals(0, vm.getNumberOfProduct1());

        enterAdminMode();
        assertEquals(0, vm.getNumberOfProduct1());
        fillProducts();
        assertEquals(30, vm.getNumberOfProduct1());
        exitAdminMode();

        assertEquals(VendingMachine.Mode.OPERATION, vm.getCurrentMode());
        assertEquals(30, vm.getNumberOfProduct1());
    }

    // ...............................................
    //b
    @Test
    void getNumberOfProduct2() {
        assertEquals(VendingMachine.Mode.OPERATION, vm.getCurrentMode());
        assertEquals(0, vm.getNumberOfProduct2());

        enterAdminMode();
        assertEquals(0, vm.getNumberOfProduct2());
        fillProducts();
        assertEquals(40, vm.getNumberOfProduct2());
        exitAdminMode();

        assertEquals(VendingMachine.Mode.OPERATION, vm.getCurrentMode());
        assertEquals(40, vm.getNumberOfProduct2());
    }

    // ...............................................
    // c
    @Test
    void getCurrentBalance() {
        assertEquals(VendingMachine.Mode.OPERATION, vm.getCurrentMode());

        assertEquals(0, vm.getCurrentBalance());
        putCoin1();
        assertEquals(VendingMachine.coinval1, vm.getCurrentBalance());
        putCoin2();
        assertEquals(VendingMachine.coinval1 + VendingMachine.coinval2, vm.getCurrentBalance());
    }

    // ...............................................
    // d
    @Test
    void getCurrentMode() {
        assertEquals(VendingMachine.Mode.OPERATION, vm.getCurrentMode());

        enterAdminMode();
        assertEquals(VendingMachine.Mode.ADMINISTERING, vm.getCurrentMode());
        exitAdminMode();

        assertEquals(VendingMachine.Mode.OPERATION, vm.getCurrentMode());
    }

    // ...............................................
    // e
    @ParameterizedTest
    @ValueSource(ints = {1, 5, 10})
    void getCurrentSum(int n) {
        fillCoins(n, n);

        assertEquals(VendingMachine.Mode.ADMINISTERING, vm.getCurrentMode());
        assertEquals(n * (VendingMachine.coinval1 + VendingMachine.coinval2), vm.getCurrentSum());
    }

    // В рабочем режиме
    @ParameterizedTest
    @ValueSource(ints = {1, 5, 10})
    void getCurrentSumOperationMode(int n) {
        assertEquals(VendingMachine.Mode.OPERATION, vm.getCurrentMode());
        assertEquals(0, vm.getCurrentSum());

        fillCoins(n, n);
        exitAdminMode();

        assertEquals(VendingMachine.Mode.OPERATION, vm.getCurrentMode());
        assertEquals(0, vm.getCurrentSum());
    }

    // ...............................................
    // f
    @ParameterizedTest
    @CsvSource(value = {
            "1, 2",
            "5, 7",
            "10, 15"})
    void getCoins1(int c1, int c2) {
        fillCoins(c1, c2);

        assertEquals(VendingMachine.Mode.ADMINISTERING, vm.getCurrentMode());
        assertEquals(c1, vm.getCoins1());
    }

    // Вне режима отладки.
    @ParameterizedTest
    @CsvSource(value = {
            "1, 2",
            "5, 7",
            "10, 15"})
    void getCoins1OperationMode(int c1, int c2) {
        assertEquals(VendingMachine.Mode.OPERATION, vm.getCurrentMode());
        assertEquals(0, vm.getCoins1());

        fillCoins(c1, c2);
        exitAdminMode();

        assertEquals(VendingMachine.Mode.OPERATION, vm.getCurrentMode());
        assertEquals(0, vm.getCoins1());
    }

    // ...............................................
    // g
    @ParameterizedTest
    @CsvSource(value = {
            "1, 2",
            "5, 7",
            "10, 15"})
    void getCoins2(int c1, int c2) {
        fillCoins(c1, c2);

        assertEquals(VendingMachine.Mode.ADMINISTERING, vm.getCurrentMode());
        assertEquals(c2, vm.getCoins2());
    }

    @ParameterizedTest
    @CsvSource(value = {
            "1, 2",
            "5, 7",
            "10, 15"})
    void getCoins2OperationMode(int c1, int c2) {
        assertEquals(VendingMachine.Mode.OPERATION, vm.getCurrentMode());
        assertEquals(0, vm.getCoins2());

        fillCoins(c1, c2);
        exitAdminMode();

        assertEquals(VendingMachine.Mode.OPERATION, vm.getCurrentMode());
        assertEquals(0, vm.getCoins2());
    }

    // ...............................................
    // h
    @ParameterizedTest
    @CsvSource(value = {
            "1, 2",
            "5, 7",
            "10, 15"})
    void getPrice1(int p1, int p2) {
        assertEquals(VendingMachine.Mode.OPERATION, vm.getCurrentMode());
        assertEquals(8, vm.getPrice1());

        enterAdminMode();
        assertEquals(8, vm.getPrice1());
        setPrices(p1, p2);
        assertEquals(p1, vm.getPrice1());
        exitAdminMode();

        assertEquals(VendingMachine.Mode.OPERATION, vm.getCurrentMode());
        assertEquals(p1, vm.getPrice1());
    }

    // ...............................................
    // i
    @ParameterizedTest
    @CsvSource(value = {
            "1, 2",
            "5, 7",
            "10, 15"})
    void getPrice2(int p1, int p2) {
        assertEquals(VendingMachine.Mode.OPERATION, vm.getCurrentMode());
        assertEquals(5, vm.getPrice2());

        enterAdminMode();
        assertEquals(5, vm.getPrice2());
        setPrices(p1, p2);
        assertEquals(p2, vm.getPrice2());
        exitAdminMode();

        assertEquals(VendingMachine.Mode.OPERATION, vm.getCurrentMode());
        assertEquals(p2, vm.getPrice2());
    }


    // ...............................................
    // j
    @Test
    void fillProducts() {
        enterAdminMode();
        assertEquals(VendingMachine.Mode.ADMINISTERING, vm.getCurrentMode());

        assertNotEquals(30, vm.getNumberOfProduct1());
        assertNotEquals(40, vm.getNumberOfProduct2());
        assertEquals(VendingMachine.Response.OK, vm.fillProducts());
        assertEquals(30, vm.getNumberOfProduct1());
        assertEquals(40, vm.getNumberOfProduct2());
    }

    // Вне режима отладки.
    @Test
    void fillProduct1WrongMode() {
        exitAdminMode();
        assertEquals(VendingMachine.Mode.OPERATION, vm.getCurrentMode());

        assertNotEquals(30, vm.getNumberOfProduct1());
        assertNotEquals(40, vm.getNumberOfProduct2());
        assertEquals(VendingMachine.Response.ILLEGAL_OPERATION, vm.fillProducts());
        assertNotEquals(30, vm.getNumberOfProduct1());
        assertNotEquals(40, vm.getNumberOfProduct2());
    }

    // ...............................................
    // k
    @ParameterizedTest
    @CsvSource(value = {
            "1, 2",
            "5, 7",
            "10, 15"})
    void fillCoins(int c1, int c2) {
        enterAdminMode();
        assertEquals(VendingMachine.Mode.ADMINISTERING, vm.getCurrentMode());

        assertNotEquals(c1, vm.getCoins1());
        assertNotEquals(c2, vm.getCoins2());
        assertEquals(VendingMachine.Response.OK, vm.fillCoins(c1, c2));
        assertEquals(c1, vm.getCoins1());
        assertEquals(c2, vm.getCoins2());
    }

    // Некорректные параметры.
    @ParameterizedTest
    @CsvSource(value = {
            "-1, 7",
            "7, -1",
            "0, 7",
            "7, 0",
            "51, 15",
            "15, 51"
    })
    void fillCoins1InvalidParam(int c1, int c2) {
        int startValue1 = vm.getCoins1();
        int startValue2 = vm.getCoins2();

        enterAdminMode();
        assertEquals(VendingMachine.Mode.ADMINISTERING, vm.getCurrentMode());

        assertEquals(VendingMachine.Response.INVALID_PARAM, vm.fillCoins(c1, c2));
        assertEquals(startValue1, vm.getCoins1());
        assertEquals(startValue2, vm.getCoins2());
    }

    // Некорректный mode.
    @ParameterizedTest
    @CsvSource(value = {
            "1, 2",
            "5, 7",
            "10, 15"})
    void fillCoins1WrongMode(int c1, int c2) {
        exitAdminMode();
        assertEquals(VendingMachine.Mode.OPERATION, vm.getCurrentMode());

        assertNotEquals(c1, vm.getCoins1());
        assertNotEquals(c2, vm.getCoins2());
        assertEquals(VendingMachine.Response.ILLEGAL_OPERATION, vm.fillCoins(c1, c2));
        assertNotEquals(c1, vm.getCoins1());
        assertNotEquals(c2, vm.getCoins2());
    }

    // ...............................................
    // l
    @Test
    void enterAdminMode() {
        if (vm.getCurrentMode() != VendingMachine.Mode.OPERATION)
            exitAdminMode();

        assertEquals(VendingMachine.Mode.OPERATION, vm.getCurrentMode());
        assertEquals(VendingMachine.Response.OK, vm.enterAdminMode(passcode));
        assertEquals(VendingMachine.Mode.ADMINISTERING, vm.getCurrentMode());
    }

    @Test
    void enterAdminModeInvalidCode() {
        assertEquals(VendingMachine.Mode.OPERATION, vm.getCurrentMode());
        assertEquals(VendingMachine.Response.INVALID_PARAM, vm.enterAdminMode(-1));
        assertNotEquals(VendingMachine.Mode.ADMINISTERING, vm.getCurrentMode());
    }

    @Test
    void enterAdminModeWithBalance() {
        putCoin1();
        assertTrue(vm.getCurrentBalance() > 0);

        assertEquals(VendingMachine.Mode.OPERATION, vm.getCurrentMode());
        assertEquals(VendingMachine.Response.CANNOT_PERFORM, vm.enterAdminMode(passcode));
        assertNotEquals(VendingMachine.Mode.ADMINISTERING, vm.getCurrentMode());
    }

    // ...............................................
    // m
    @Test
    void exitAdminMode() {
        if (vm.getCurrentMode() != VendingMachine.Mode.ADMINISTERING)
            enterAdminMode();

        assertEquals(VendingMachine.Mode.ADMINISTERING, vm.getCurrentMode());
        vm.exitAdminMode();
        assertEquals(VendingMachine.Mode.OPERATION, vm.getCurrentMode());
    }

    // ...............................................
    // n
    @ParameterizedTest
    @CsvSource(value = {
            "1, 2",
            "5, 7",
            "10, 15"})
    void setPrices(int p1, int p2) {
        enterAdminMode();
        assertEquals(VendingMachine.Mode.ADMINISTERING, vm.getCurrentMode());

        assertNotEquals(p1, vm.getPrice1());
        assertNotEquals(p2, vm.getPrice2());
        assertEquals(VendingMachine.Response.OK, vm.setPrices(p1, p2));
        assertEquals(p1, vm.getPrice1());
        assertEquals(p2, vm.getPrice2());
    }

    @ParameterizedTest
    @CsvSource(value = {
            "1, 2",
            "5, 7",
            "10, 15"})
    void setPriceWrongMode(int p1, int p2) {
        exitAdminMode();

        assertNotEquals(p1, vm.getPrice1());
        assertNotEquals(p2, vm.getPrice2());
        assertEquals(VendingMachine.Response.ILLEGAL_OPERATION, vm.setPrices(p1, p2));
        assertNotEquals(p1, vm.getPrice1());
        assertNotEquals(p2, vm.getPrice2());
    }

    @ParameterizedTest
    @CsvSource(value = {
            "-10, 2",
            "5, -10",
            "0, 2",
            "5, 0"})
    void setPriceInvalidParams(int p1, int p2) {
        enterAdminMode();

        assertNotEquals(p1, vm.getPrice1());
        assertNotEquals(p2, vm.getPrice2());
        assertEquals(VendingMachine.Response.INVALID_PARAM, vm.setPrices(p1, p2));
        assertNotEquals(p1, vm.getPrice1());
        assertNotEquals(p2, vm.getPrice2());
    }

    // ...............................................
    // o
    @Test
    void putCoin1() {
        int startValue = vm.getCurrentBalance();
        assertEquals(VendingMachine.Mode.OPERATION, vm.getCurrentMode());

        assertEquals(VendingMachine.Response.OK, vm.putCoin1());
        assertEquals(startValue  + VendingMachine.coinval1, vm.getCurrentBalance());
    }

    @Test
    void putCoin1WrongMode() {
        int startValue = vm.getCurrentBalance();

        enterAdminMode();
        assertEquals(VendingMachine.Mode.ADMINISTERING, vm.getCurrentMode());

        assertEquals(VendingMachine.Response.ILLEGAL_OPERATION, vm.putCoin1());
        assertEquals(startValue, vm.getCurrentBalance());
    }

    @Test
    void putCoin1Overflow() {
        fillCoins(50, 1);
        int startValue = vm.getCoins1();

        exitAdminMode();
        assertEquals(VendingMachine.Mode.OPERATION, vm.getCurrentMode());

        assertEquals(VendingMachine.Response.CANNOT_PERFORM, vm.putCoin1());

        enterAdminMode();
        assertEquals(startValue, vm.getCoins1());
    }

    // ...............................................
    // p
    @Test
    void putCoin2() {
        int startValue = vm.getCurrentBalance();
        assertEquals(VendingMachine.Mode.OPERATION, vm.getCurrentMode());

        assertEquals(VendingMachine.Response.OK, vm.putCoin2());
        assertEquals(startValue  + VendingMachine.coinval2, vm.getCurrentBalance());
    }

    @Test
    void putCoin2WrongMode() {
        int startValue = vm.getCurrentBalance();

        enterAdminMode();
        assertEquals(VendingMachine.Mode.ADMINISTERING, vm.getCurrentMode());

        assertEquals(VendingMachine.Response.ILLEGAL_OPERATION, vm.putCoin2());
        assertEquals(startValue, vm.getCurrentBalance());
    }

    @Test
    void putCoin2Overflow() {
        fillCoins(1, 50);
        int startValue = vm.getCoins2();

        exitAdminMode();
        assertEquals(VendingMachine.Mode.OPERATION, vm.getCurrentMode());

        assertEquals(VendingMachine.Response.CANNOT_PERFORM, vm.putCoin2());

        enterAdminMode();
        assertEquals(startValue, vm.getCoins2());
    }

    // ...............................................
    // q
    @Test
    void returnMoneyZeroBalance() {
        fillCoins(1, 1);
        exitAdminMode();
        assertEquals(VendingMachine.Mode.OPERATION, vm.getCurrentMode());

        assertEquals(0, vm.getCurrentBalance());
        assertEquals(VendingMachine.Response.OK, vm.returnMoney());

        enterAdminMode();
        assertEquals(1, vm.getCoins1());
        assertEquals(1, vm.getCoins2());
    }

    @ParameterizedTest
    @ValueSource(ints = {5, 9, 13})
    void returnMoneyMoreThanSumOfCoins2(int n) {
        fillCoins(1, n / 2 - 1);

        exitAdminMode();
        assertEquals(VendingMachine.Mode.OPERATION, vm.getCurrentMode());

        for (int i = 0; i < n; i++) putCoin1();

        assertEquals(n, vm.getCurrentBalance());
        assertEquals(VendingMachine.Response.OK, vm.returnMoney());
        assertEquals(0, vm.getCurrentBalance());

        enterAdminMode();
        assertEquals(n - 3, vm.getCoins1() - 1);
        assertEquals(0, vm.getCoins2());
    }

    @ParameterizedTest
    @ValueSource(ints = {4, 10, 14})
    void returnMoneyEvenBalance(int n) {
        fillCoins(1, n);

        exitAdminMode();
        assertEquals(VendingMachine.Mode.OPERATION, vm.getCurrentMode());

        for (int i = 0; i < n; i++) putCoin1();

        assertEquals(n, vm.getCurrentBalance());
        assertEquals(VendingMachine.Response.OK, vm.returnMoney());
        assertEquals(0, vm.getCurrentBalance());
        // Должны выдаться все монеты 2 вида

        enterAdminMode();
        assertEquals(n, vm.getCoins1() - 1);
        assertEquals(n / 2, vm.getCoins2());
    }

    @ParameterizedTest
    @ValueSource(ints = {8, 10, 14})
    void returnMoneyEvenBalanceNotEnoughCoin2(int n) {
        fillCoins(1, n / 2 - 2);

        exitAdminMode();
        assertEquals(VendingMachine.Mode.OPERATION, vm.getCurrentMode());

        for (int i = 0; i < n; i++) putCoin1();

        assertEquals(n, vm.getCurrentBalance());
        assertEquals(VendingMachine.Response.OK, vm.returnMoney());
        assertEquals(0, vm.getCurrentBalance());
        // Должны выдаться все монеты 2 вида

        enterAdminMode();
        assertEquals(n - 4, vm.getCoins1() - 1);
        assertEquals(0, vm.getCoins2());
    }

    @ParameterizedTest
    @ValueSource(ints = {5, 11, 15})
    void returnMoneyOddBalance(int n) {
        fillCoins(1, n);

        exitAdminMode();
        assertEquals(VendingMachine.Mode.OPERATION, vm.getCurrentMode());

        for (int i = 0; i < n; i++) putCoin1();

        assertEquals(n, vm.getCurrentBalance());
        assertEquals(VendingMachine.Response.OK, vm.returnMoney());
        assertEquals(0, vm.getCurrentBalance());
        // Должны выдаться все монеты 2 вида

        enterAdminMode();
        assertEquals(n - 1, vm.getCoins1() - 1);
        assertEquals(n / 2 + 1, vm.getCoins2());
    }

    @Test
    void returnMoneyWrongMode() {
        fillCoins(1, 1);

        assertNotEquals(VendingMachine.Mode.OPERATION, vm.getCurrentMode());

        assertEquals(VendingMachine.Response.ILLEGAL_OPERATION, vm.returnMoney());

        assertEquals(1, vm.getCoins1());
        assertEquals(1, vm.getCoins2());
    }

    // ...............................................
    // r

    @ParameterizedTest
    @ValueSource(ints = {1, 3, 5})
    void giveProduct1NoChange(int n) {
        fillProducts();

        exitAdminMode();
        assertEquals(VendingMachine.Mode.OPERATION, vm.getCurrentMode());

        for (int i = 0; i < n * 4; i++) putCoin2();

        assertEquals(8 * n, vm.getCurrentBalance());
        assertEquals(VendingMachine.Response.OK, vm.giveProduct1(n));
        assertEquals(0, vm.getCurrentBalance());

        enterAdminMode();
        assertEquals(30 - n, vm.getNumberOfProduct1());
    }

    @ParameterizedTest
    @ValueSource(ints = {1, 3, 5})
    void giveProduct1EvenChange(int n) {
        fillProducts();
        fillCoins(1, 5);

        exitAdminMode();
        assertEquals(VendingMachine.Mode.OPERATION, vm.getCurrentMode());

        for (int i = 0; i < n * 8 + 4; i++) putCoin1();

        assertEquals(n * 8 + 4, vm.getCurrentBalance());
        assertEquals(VendingMachine.Response.OK, vm.giveProduct1(n));
        assertEquals(0, vm.getCurrentBalance());

        enterAdminMode();
        assertEquals(30 - n, vm.getNumberOfProduct1());
        assertEquals(3, vm.getCoins2());
    }

    @ParameterizedTest
    @ValueSource(ints = {1, 3, 5})
    void giveProduct1EvenChangeNotEnoughCoin2(int n) {
        fillProducts();
        fillCoins(1, 1);

        exitAdminMode();
        assertEquals(VendingMachine.Mode.OPERATION, vm.getCurrentMode());

        for (int i = 0; i < n * 8 + 4; i++) putCoin1();

        assertEquals(VendingMachine.Response.OK, vm.giveProduct1(n));
        assertEquals(0, vm.getCurrentBalance());

        enterAdminMode();
        assertEquals(30 - n, vm.getNumberOfProduct1());
        assertEquals(n * 8 + 2, vm.getCoins1() - 1);
        assertEquals(0, vm.getCoins2());
    }

    @ParameterizedTest
    @ValueSource(ints = {1, 3, 5})
    void giveProduct1OddChange(int n) {
        fillProducts();
        fillCoins(1, 5);

        exitAdminMode();
        assertEquals(VendingMachine.Mode.OPERATION, vm.getCurrentMode());

        for (int i = 0; i < n * 8 + 5; i++) putCoin1();

        assertEquals(VendingMachine.Response.OK, vm.giveProduct1(n));
        assertEquals(0, vm.getCurrentBalance());

        enterAdminMode();
        assertEquals(30 - n, vm.getNumberOfProduct1());
        assertEquals(n * 8 + 4, vm.getCoins1() - 1);
        assertEquals(3, vm.getCoins2());
    }

    @ParameterizedTest
    @ValueSource(ints = {0, -1, 31})
    void giveProduct1InvalidParam(int n) {
        fillProducts();

        exitAdminMode();
        assertEquals(VendingMachine.Mode.OPERATION, vm.getCurrentMode());

        assertEquals(VendingMachine.Response.INVALID_PARAM, vm.giveProduct1(n));

        enterAdminMode();
        assertEquals(30, vm.getNumberOfProduct1());
    }

    @ParameterizedTest
    @ValueSource(ints = {1, 3, 5})
    void giveProduct1NotEnoughProduct(int n) {
        enterAdminMode();
        assertTrue(vm.getNumberOfProduct1() < n);
        exitAdminMode();

        assertEquals(VendingMachine.Mode.OPERATION, vm.getCurrentMode());
        assertEquals(VendingMachine.Response.INSUFFICIENT_PRODUCT, vm.giveProduct1(n));
    }

    @ParameterizedTest
    @ValueSource(ints = {1, 3, 5})
    void giveProduct1NotEnoughMoney(int n) {
        fillProducts();

        exitAdminMode();
        assertEquals(VendingMachine.Mode.OPERATION, vm.getCurrentMode());

        assertEquals(VendingMachine.Response.INSUFFICIENT_MONEY, vm.giveProduct1(n));

        enterAdminMode();
        assertEquals(30, vm.getNumberOfProduct1());
    }

    @ParameterizedTest
    @ValueSource(ints = {1, 3, 5})
    void giveProduct1UnsuitableChange(int n) {
        fillProducts();
        setPrices(1, 7);

        exitAdminMode();
        assertEquals(VendingMachine.Mode.OPERATION, vm.getCurrentMode());

        for (int i = 0; i < n * 4; i++) putCoin2();

        assertEquals(VendingMachine.Response.UNSUITABLE_CHANGE, vm.giveProduct1(n));
        assertEquals(n * 8, vm.getCurrentBalance());

        vm.returnMoney();

        enterAdminMode();
        assertEquals(30, vm.getNumberOfProduct1());
    }

    @Test
    void giveProduct1WrongMode() {
        fillProducts();

        assertEquals(VendingMachine.Mode.ADMINISTERING, vm.getCurrentMode());
        assertEquals(VendingMachine.Response.ILLEGAL_OPERATION, vm.giveProduct1(1));

        assertEquals(30, vm.getNumberOfProduct1());
    }

    // ...............................................
    // s
    @ParameterizedTest
    @ValueSource(ints = {1, 3, 5})
    void giveProduct2NoChange(int n) {
        fillProducts();

        exitAdminMode();
        assertEquals(VendingMachine.Mode.OPERATION, vm.getCurrentMode());

        for (int i = 0; i < n * 5; i++) putCoin1();

        assertEquals(5 * n, vm.getCurrentBalance());
        assertEquals(VendingMachine.Response.OK, vm.giveProduct2(n));
        assertEquals(0, vm.getCurrentBalance());

        enterAdminMode();
        assertEquals(40 - n, vm.getNumberOfProduct2());
    }

    @ParameterizedTest
    @ValueSource(ints = {1, 3, 5})
    void giveProduct2EvenChange(int n) {
        fillProducts();
        fillCoins(1, 5);

        exitAdminMode();
        assertEquals(VendingMachine.Mode.OPERATION, vm.getCurrentMode());

        for (int i = 0; i < n * 5 + 4; i++) putCoin1();

        assertEquals(n * 5 + 4, vm.getCurrentBalance());
        assertEquals(VendingMachine.Response.OK, vm.giveProduct2(n));
        assertEquals(0, vm.getCurrentBalance());

        enterAdminMode();
        assertEquals(40 - n, vm.getNumberOfProduct2());
        assertEquals(3, vm.getCoins2());
    }

    @ParameterizedTest
    @ValueSource(ints = {1, 3, 5})
    void giveProduct2EvenChangeNotEnoughCoin2(int n) {
        fillProducts();
        fillCoins(1, 1);

        exitAdminMode();
        assertEquals(VendingMachine.Mode.OPERATION, vm.getCurrentMode());

        for (int i = 0; i < n * 5 + 4; i++) putCoin1();

        assertEquals(n * 5 + 4, vm.getCurrentBalance());
        assertEquals(VendingMachine.Response.OK, vm.giveProduct2(n));
        assertEquals(0, vm.getCurrentBalance());

        enterAdminMode();
        assertEquals(40 - n, vm.getNumberOfProduct2());
        assertEquals(n * 5 + 2, vm.getCoins1() - 1);
        assertEquals(0, vm.getCoins2());
    }

    @ParameterizedTest
    @ValueSource(ints = {1, 3, 5})
    void giveProduct2OddChange(int n) {
        fillProducts();
        fillCoins(1, 5);

        exitAdminMode();
        assertEquals(VendingMachine.Mode.OPERATION, vm.getCurrentMode());

        for (int i = 0; i < n * 5 + 5; i++) putCoin1();

        assertEquals(n * 5 + 5, vm.getCurrentBalance());
        assertEquals(VendingMachine.Response.OK, vm.giveProduct2(n));
        assertEquals(0, vm.getCurrentBalance());

        enterAdminMode();
        assertEquals(40 - n, vm.getNumberOfProduct2());
        assertEquals(n * 5 + 4, vm.getCoins1() - 1);
        assertEquals(3, vm.getCoins2());
    }

    @ParameterizedTest
    @ValueSource(ints = {0, -1, 41})
    void giveProduct2InvalidParam(int n) {
        fillProducts();

        exitAdminMode();
        assertEquals(VendingMachine.Mode.OPERATION, vm.getCurrentMode());

        assertEquals(VendingMachine.Response.INVALID_PARAM, vm.giveProduct2(n));

        enterAdminMode();
        assertEquals(40, vm.getNumberOfProduct2());
    }

    @ParameterizedTest
    @ValueSource(ints = {1, 3, 5})
    void giveProduct2NotEnoughProduct(int n) {
        enterAdminMode();
        assertTrue(vm.getNumberOfProduct2() < n);
        exitAdminMode();

        assertEquals(VendingMachine.Mode.OPERATION, vm.getCurrentMode());
        assertEquals(VendingMachine.Response.INSUFFICIENT_PRODUCT, vm.giveProduct2(n));
    }

    @ParameterizedTest
    @ValueSource(ints = {1, 3, 5})
    void giveProduct2NotEnoughMoney(int n) {
        fillProducts();

        exitAdminMode();
        assertEquals(VendingMachine.Mode.OPERATION, vm.getCurrentMode());

        assertEquals(VendingMachine.Response.INSUFFICIENT_MONEY, vm.giveProduct2(n));

        enterAdminMode();
        assertEquals(40, vm.getNumberOfProduct2());
    }

    @ParameterizedTest
    @ValueSource(ints = {1, 3, 5})
    void giveProduct2UnsuitableChange(int n) {
        fillProducts();

        exitAdminMode();
        assertEquals(VendingMachine.Mode.OPERATION, vm.getCurrentMode());

        for (int i = 0; i < n * 3; i++) putCoin2();

        assertEquals(VendingMachine.Response.UNSUITABLE_CHANGE, vm.giveProduct2(n));
        assertEquals(n * 3 * 2, vm.getCurrentBalance());

        vm.returnMoney();

        enterAdminMode();
        assertEquals(40, vm.getNumberOfProduct2());
    }

    @Test
    void giveProduct2WrongMode() {
        fillProducts();

        assertEquals(VendingMachine.Mode.ADMINISTERING, vm.getCurrentMode());
        assertEquals(VendingMachine.Response.ILLEGAL_OPERATION, vm.giveProduct2(1));

        assertEquals(40, vm.getNumberOfProduct2());
    }
}