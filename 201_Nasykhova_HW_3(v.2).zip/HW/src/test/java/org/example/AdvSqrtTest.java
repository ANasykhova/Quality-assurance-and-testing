package org.example;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.Timeout;

import java.time.Duration;
import java.util.concurrent.TimeUnit;

import static org.junit.jupiter.api.Assertions.*;

class AdvSqrtTest {
    AdvSqrt advSqrt = new AdvSqrt();
    Sqrt sqrt = new Sqrt();

    /**
     * Helper.
     */
    void assertAnswer(double expected, double actual) {
        long a = Double.doubleToLongBits(actual);
        long e = Double.doubleToLongBits(expected);
        assertTrue(Math.abs(a - e) <= 1);
    }

    // !!! NEW.
    @Test
    void findingMistake() {
        double value = 23.78;
        assertTimeoutPreemptively(Duration.ofMillis(1000), () -> {
            advSqrt.sqrt(value);
        });
    }

    // First: Default double.
    @Test
    void positiveZero() {
        assertAnswer(0, advSqrt.sqrt(0));
    }

    @Test
    void one() {
        assertAnswer(1, advSqrt.sqrt(1));
    }

    @Test
    void positiveZeroExponent() {
        double value = Double.longBitsToDouble(0x0000000000000011L);
        assertAnswer(Math.sqrt(value), advSqrt.sqrt(value));
    }

    @Test
    void positiveNonZeroEvenExponent() {
        double value = Double.longBitsToDouble(0x0080000000011L);
        assertAnswer(Math.sqrt(value), advSqrt.sqrt(value));
    }

    @Test
    void positiveNonZeroOddExponent() {
        double value = Double.longBitsToDouble(0x0030000008000312L);
        assertAnswer(Math.sqrt(value), advSqrt.sqrt(value));
    }

    // Second: Negative not Zero.

    // !!! Delete random.
    @Test
    void negative() {
        assertTrue(Double.isNaN(advSqrt.sqrt(-121947.316)));
    }

    // Third: Negative Zero.
    @Test
    void negativeZero() {
        assertAnswer(-0.0, advSqrt.sqrt(-0.0));
    }

    // Fourth: Infinite.
    @Test
    void positiveInf() {
        assertAnswer(Double.POSITIVE_INFINITY, advSqrt.sqrt(Double.POSITIVE_INFINITY));
    }

    @Test
    void negativeInf() {
        assertTrue(Double.isNaN(advSqrt.sqrt(Double.NEGATIVE_INFINITY)));
    }

    // Fifth: NaN.
    @Test
    void sqrtNaN() {
        assertAnswer(Double.NaN, advSqrt.sqrt(Double.NaN));
        assertAnswer(Double.NaN, sqrt.sqrt(Double.NaN));
    }

}