package org.example;

/**
 * @author Victor Kuliamin
 */

public class Sqrt {
    public double sqrt(double x) {
        return Math.sqrt(x);
    }
}
