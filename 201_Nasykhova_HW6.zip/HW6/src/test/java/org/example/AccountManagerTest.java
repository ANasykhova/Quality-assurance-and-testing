package org.example;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class AccountManagerTest {
    @Mock
    private IServer serverMock;

    @Spy
    private AccountManager accountManager;

    private final Long sessionNumber = 1L;
    private final Double amount = 100D;
    private final Double balance = 100D;

    @BeforeEach
    void setUp() {
        accountManager.init(serverMock);
    }

    //-------------------------------------------------------------
    // callLogin
    @Test
    void callLoginSuccess() {
        when(serverMock.login("userName", "mdPass")).thenReturn(new ServerResponse(ServerResponse.SUCCESS, sessionNumber));
        when(accountManager.makeSecure(anyString())).thenReturn("mdPass");
        AccountManagerResponse result = accountManager.callLogin("userName", "mdPass");
        assertEquals(AccountManagerResponse.SUCCEED, result.code);
        assertEquals(sessionNumber, result.response);

        when(serverMock.logout(sessionNumber)).thenReturn(new ServerResponse(ServerResponse.SUCCESS, sessionNumber));
        AccountManagerResponse resultAfterLogout = accountManager.callLogout("userName", sessionNumber);
        assertEquals(AccountManagerResponse.SUCCEED_RESPONSE, resultAfterLogout);
    }

    @Test
    void callLoginAlreadyLoggedServer() {
        when(serverMock.login("userName", "mdPass")).thenReturn(new ServerResponse(ServerResponse.ALREADY_LOGGED, sessionNumber));
        when(accountManager.makeSecure(anyString())).thenReturn("mdPass");
        AccountManagerResponse result = accountManager.callLogin("userName", "mdPass");
        assertEquals(AccountManagerResponse.ACCOUNT_MANAGER_RESPONSE, result);
    }

    @Test
    void callLoginAlreadyLogged() {
        when(serverMock.login("userName", "mdPass")).thenReturn(new ServerResponse(ServerResponse.SUCCESS, sessionNumber));
        when(accountManager.makeSecure(anyString())).thenReturn("mdPass");
        accountManager.callLogin("userName", "mdPass");
        AccountManagerResponse resultNew = accountManager.callLogin("userName", "mdPass");
        assertEquals(AccountManagerResponse.ACCOUNT_MANAGER_RESPONSE, resultNew);
    }

    @Test
    void callLoginNoUserIncorrectPassword() {
        when(serverMock.login("userName", "mdPass")).thenReturn(new ServerResponse(ServerResponse.NO_USER_INCORRECT_PASSWORD, sessionNumber));
        when(accountManager.makeSecure(anyString())).thenReturn("mdPass");
        AccountManagerResponse result = accountManager.callLogin("userName", "mdPass");
        assertEquals(AccountManagerResponse.NO_USER_INCORRECT_PASSWORD_RESPONSE, result);
    }

    @Test
    void callLoginIncorrect() {
        when(serverMock.login("userName", "mdPass")).thenReturn(new ServerResponse(ServerResponse.UNDEFINED_ERROR, sessionNumber));
        when(accountManager.makeSecure(anyString())).thenReturn("mdPass");
        AccountManagerResponse result = accountManager.callLogin("userName", "mdPass");
        assertEquals(AccountManagerResponse.UNDEFINED_ERROR_RESPONSE, result);
    }

    @Test
    void callLoginSucceedNotLong() {
        int sessionNumber = 1;
        when(serverMock.login("userName", "mdPass")).thenReturn(new ServerResponse(ServerResponse.SUCCESS, sessionNumber));
        when(accountManager.makeSecure(anyString())).thenReturn("mdPass");
        AccountManagerResponse result = accountManager.callLogin("userName", "mdPass");
        assertEquals(AccountManagerResponse.UNDEFINED_ERROR_RESPONSE, result);
    }

    //-------------------------------------------------------------
    // callLogout
    @Test
    void callLogoutSuccess() {
        when(serverMock.login("userName", "mdPass")).thenReturn(new ServerResponse(ServerResponse.SUCCESS, sessionNumber));
        when(accountManager.makeSecure(anyString())).thenReturn("mdPass");
        accountManager.callLogin("userName", "mdPass");

        when(serverMock.logout(sessionNumber)).thenReturn(new ServerResponse(ServerResponse.SUCCESS, sessionNumber));
        AccountManagerResponse resultAfterLogout = accountManager.callLogout("userName", sessionNumber);
        assertEquals(AccountManagerResponse.SUCCEED_RESPONSE, resultAfterLogout);
    }

    @Test
    void callLogoutNotLoggedNoUserInTable() {
        AccountManagerResponse resultAfterLogout = accountManager.callLogout("userName", sessionNumber);
        assertEquals(AccountManagerResponse.NOT_LOGGED_RESPONSE, resultAfterLogout);
    }

    @Test
    void callLogoutNotLogged() {
        when(serverMock.login("userName", "mdPass")).thenReturn(new ServerResponse(ServerResponse.SUCCESS, sessionNumber));
        when(accountManager.makeSecure(anyString())).thenReturn("mdPass");
        accountManager.callLogin("userName", "mdPass");

        when(serverMock.logout(sessionNumber)).thenReturn(new ServerResponse(ServerResponse.NOT_LOGGED, sessionNumber));
        AccountManagerResponse resultAfterLogout = accountManager.callLogout("userName", sessionNumber);
        assertEquals(AccountManagerResponse.NOT_LOGGED_RESPONSE, resultAfterLogout);
    }

    @Test
    void callLogoutIncorrect() {
        when(serverMock.login("userName", "mdPass")).thenReturn(new ServerResponse(ServerResponse.SUCCESS, sessionNumber));
        when(accountManager.makeSecure(anyString())).thenReturn("mdPass");
        accountManager.callLogin("userName", "mdPass");

        when(serverMock.logout(sessionNumber)).thenReturn(new ServerResponse(ServerResponse.UNDEFINED_ERROR, sessionNumber));
        AccountManagerResponse resultAfterLogout = accountManager.callLogout("userName", sessionNumber);
        assertEquals(AccountManagerResponse.UNDEFINED_ERROR_RESPONSE, resultAfterLogout);
    }

    @Test
    void callLogoutIncorrectSession() {
        when(serverMock.login("userName", "mdPass")).thenReturn(new ServerResponse(ServerResponse.SUCCESS, sessionNumber));
        when(accountManager.makeSecure(anyString())).thenReturn("mdPass");
        accountManager.callLogin("userName", "mdPass");

        AccountManagerResponse result = accountManager.callLogout("userName", 2L);
        assertEquals(AccountManagerResponse.INCORRECT_SESSION_RESPONSE, result);
    }

    //-------------------------------------------------------------
    // withdraw
    @Test
    void withdrawSuccess() {
        when(serverMock.login("userName", "mdPass")).thenReturn(new ServerResponse(ServerResponse.SUCCESS, sessionNumber));
        when(accountManager.makeSecure(anyString())).thenReturn("mdPass");
        accountManager.callLogin("userName", "mdPass");

        when(serverMock.getBalance(sessionNumber)).thenReturn(new ServerResponse(ServerResponse.SUCCESS, balance));
        AccountManagerResponse getBalanceResult = accountManager.getBalance("userName", sessionNumber);
        assertEquals(AccountManagerResponse.SUCCEED, getBalanceResult.code);
        assertEquals(balance, getBalanceResult.response);

        when(serverMock.withdraw(sessionNumber, amount)).thenReturn(new ServerResponse(ServerResponse.SUCCESS, (Double)getBalanceResult.response - amount));
        AccountManagerResponse result = accountManager.withdraw("userName", sessionNumber, amount);
        assertEquals(AccountManagerResponse.SUCCEED, result.code);
        assertEquals(balance - amount, result.response);

        when(serverMock.logout(sessionNumber)).thenReturn(new ServerResponse(ServerResponse.SUCCESS, sessionNumber));
        AccountManagerResponse resultAfterLogout = accountManager.callLogout("userName", sessionNumber);
        assertEquals(AccountManagerResponse.SUCCEED_RESPONSE, resultAfterLogout);
    }

    @Test
    void withdrawNotLoggedInTable() {
        AccountManagerResponse result = accountManager.withdraw("userName", sessionNumber, amount);
        assertEquals(AccountManagerResponse.NOT_LOGGED_RESPONSE, result);
    }

    @Test
    void withdrawNotLogged() {
        when(serverMock.login("userName", "mdPass")).thenReturn(new ServerResponse(ServerResponse.SUCCESS, sessionNumber));
        when(accountManager.makeSecure(anyString())).thenReturn("mdPass");
        accountManager.callLogin("userName", "mdPass");

        when(serverMock.withdraw(sessionNumber, amount)).thenReturn(new ServerResponse(ServerResponse.NOT_LOGGED, null));
        AccountManagerResponse result = accountManager.withdraw("userName", sessionNumber, amount);
        assertEquals(AccountManagerResponse.NOT_LOGGED_RESPONSE, result);

        when(serverMock.logout(sessionNumber)).thenReturn(new ServerResponse(ServerResponse.SUCCESS, sessionNumber));
        AccountManagerResponse resultAfterLogout = accountManager.callLogout("userName", sessionNumber);
        assertEquals(AccountManagerResponse.SUCCEED_RESPONSE, resultAfterLogout);
    }

    @Test
    void withdrawNotDoubleSuccess() {
        when(serverMock.login("userName", "mdPass")).thenReturn(new ServerResponse(ServerResponse.SUCCESS, sessionNumber));
        when(accountManager.makeSecure(anyString())).thenReturn("mdPass");
        accountManager.callLogin("userName", "mdPass");

        when(serverMock.getBalance(sessionNumber)).thenReturn(new ServerResponse(ServerResponse.SUCCESS, balance));
        AccountManagerResponse getBalanceResult = accountManager.getBalance("userName", sessionNumber);
        assertEquals(AccountManagerResponse.SUCCEED, getBalanceResult.code);
        assertEquals(balance, getBalanceResult.response);

        int amount = 100;
        when(serverMock.withdraw(sessionNumber, amount)).thenReturn(new ServerResponse(ServerResponse.SUCCESS, ((Double)getBalanceResult.response).intValue() - amount));
        AccountManagerResponse result = accountManager.withdraw("userName", sessionNumber, amount);
        assertEquals(AccountManagerResponse.UNDEFINED_ERROR_RESPONSE, result);

        when(serverMock.logout(sessionNumber)).thenReturn(new ServerResponse(ServerResponse.SUCCESS, sessionNumber));
        AccountManagerResponse resultAfterLogout = accountManager.callLogout("userName", sessionNumber);
        assertEquals(AccountManagerResponse.SUCCEED_RESPONSE, resultAfterLogout);
    }

    @Test
    void withdrawNullSuccess() {
        when(serverMock.login("userName", "mdPass")).thenReturn(new ServerResponse(ServerResponse.SUCCESS, sessionNumber));
        when(accountManager.makeSecure(anyString())).thenReturn("mdPass");
        accountManager.callLogin("userName", "mdPass");

        when(serverMock.withdraw(sessionNumber, amount)).thenReturn(new ServerResponse(ServerResponse.SUCCESS, null));
        AccountManagerResponse result = accountManager.withdraw("userName", sessionNumber, amount);
        assertEquals(AccountManagerResponse.UNDEFINED_ERROR_RESPONSE, result);

        when(serverMock.logout(sessionNumber)).thenReturn(new ServerResponse(ServerResponse.SUCCESS, sessionNumber));
        AccountManagerResponse resultAfterLogout = accountManager.callLogout("userName", sessionNumber);
        assertEquals(AccountManagerResponse.SUCCEED_RESPONSE, resultAfterLogout);
    }

    @Test
    void withdrawIncorrectSession() {
        when(serverMock.login("userName", "mdPass")).thenReturn(new ServerResponse(ServerResponse.SUCCESS, sessionNumber));
        when(accountManager.makeSecure(anyString())).thenReturn("mdPass");
        accountManager.callLogin("userName", "mdPass");

        AccountManagerResponse result = accountManager.withdraw("userName", 2L, amount);
        assertEquals(AccountManagerResponse.INCORRECT_SESSION_RESPONSE, result);

        when(serverMock.logout(sessionNumber)).thenReturn(new ServerResponse(ServerResponse.SUCCESS, sessionNumber));
        AccountManagerResponse resultAfterLogout = accountManager.callLogout("userName", sessionNumber);
        assertEquals(AccountManagerResponse.SUCCEED_RESPONSE, resultAfterLogout);
    }

    @Test
    void withdrawIncorrect() {
        when(serverMock.login("userName", "mdPass")).thenReturn(new ServerResponse(ServerResponse.SUCCESS, sessionNumber));
        when(accountManager.makeSecure(anyString())).thenReturn("mdPass");
        accountManager.callLogin("userName", "mdPass");

        when(serverMock.withdraw(sessionNumber, amount)).thenReturn(new ServerResponse(ServerResponse.UNDEFINED_ERROR, null));
        AccountManagerResponse result = accountManager.withdraw("userName", sessionNumber, amount);
        assertEquals(AccountManagerResponse.UNDEFINED_ERROR_RESPONSE, result);

        when(serverMock.logout(sessionNumber)).thenReturn(new ServerResponse(ServerResponse.SUCCESS, sessionNumber));
        AccountManagerResponse resultAfterLogout = accountManager.callLogout("userName", sessionNumber);
        assertEquals(AccountManagerResponse.SUCCEED_RESPONSE, resultAfterLogout);
    }

    @Test
    void withdrawNoMoney() {
        when(serverMock.login("userName", "mdPass")).thenReturn(new ServerResponse(ServerResponse.SUCCESS, sessionNumber));
        when(accountManager.makeSecure(anyString())).thenReturn("mdPass");
        accountManager.callLogin("userName", "mdPass");

        when(serverMock.getBalance(sessionNumber)).thenReturn(new ServerResponse(ServerResponse.SUCCESS, balance));
        AccountManagerResponse getBalanceResult = accountManager.getBalance("userName", sessionNumber);
        assertEquals(AccountManagerResponse.SUCCEED, getBalanceResult.code);
        assertEquals(balance, getBalanceResult.response);

        when(serverMock.withdraw(sessionNumber, amount)).thenReturn(new ServerResponse(ServerResponse.NO_MONEY, getBalanceResult.response));
        AccountManagerResponse result = accountManager.withdraw("userName", sessionNumber, amount);
        assertEquals(AccountManagerResponse.NO_MONEY_RESPONSE, result);

        when(serverMock.logout(sessionNumber)).thenReturn(new ServerResponse(ServerResponse.SUCCESS, sessionNumber));
        AccountManagerResponse resultAfterLogout = accountManager.callLogout("userName", sessionNumber);
        assertEquals(AccountManagerResponse.SUCCEED_RESPONSE, resultAfterLogout);
    }

    @Test
    void withdrawNotDoubleNoMoney() {
        when(serverMock.login("userName", "mdPass")).thenReturn(new ServerResponse(ServerResponse.SUCCESS, sessionNumber));
        when(accountManager.makeSecure(anyString())).thenReturn("mdPass");
        accountManager.callLogin("userName", "mdPass");

        when(serverMock.getBalance(sessionNumber)).thenReturn(new ServerResponse(ServerResponse.SUCCESS, balance));
        AccountManagerResponse getBalanceResult = accountManager.getBalance("userName", sessionNumber);
        assertEquals(AccountManagerResponse.SUCCEED, getBalanceResult.code);
        assertEquals(balance, getBalanceResult.response);

        when(serverMock.withdraw(sessionNumber, amount)).thenReturn(new ServerResponse(ServerResponse.NO_MONEY, ((Double)getBalanceResult.response).intValue()));
        AccountManagerResponse result = accountManager.withdraw("userName", sessionNumber, amount);
        assertEquals(AccountManagerResponse.UNDEFINED_ERROR_RESPONSE, result);

        when(serverMock.logout(sessionNumber)).thenReturn(new ServerResponse(ServerResponse.SUCCESS, sessionNumber));
        AccountManagerResponse resultAfterLogout = accountManager.callLogout("userName", sessionNumber);
        assertEquals(AccountManagerResponse.SUCCEED_RESPONSE, resultAfterLogout);
    }

    @Test
    void withdrawNullNoMoney() {
        when(serverMock.login("userName", "mdPass")).thenReturn(new ServerResponse(ServerResponse.SUCCESS, sessionNumber));
        when(accountManager.makeSecure(anyString())).thenReturn("mdPass");
        accountManager.callLogin("userName", "mdPass");

        when(serverMock.withdraw(sessionNumber, amount)).thenReturn(new ServerResponse(ServerResponse.NO_MONEY, null));
        AccountManagerResponse result = accountManager.withdraw("userName", sessionNumber, amount);
        assertEquals(AccountManagerResponse.UNDEFINED_ERROR_RESPONSE, result);

        when(serverMock.logout(sessionNumber)).thenReturn(new ServerResponse(ServerResponse.SUCCESS, sessionNumber));
        AccountManagerResponse resultAfterLogout = accountManager.callLogout("userName", sessionNumber);
        assertEquals(AccountManagerResponse.SUCCEED_RESPONSE, resultAfterLogout);
    }

    //-------------------------------------------------------------
    // deposit
    @Test
    void depositSuccess() {
        when(serverMock.login("userName", "mdPass")).thenReturn(new ServerResponse(ServerResponse.SUCCESS, sessionNumber));
        when(accountManager.makeSecure(anyString())).thenReturn("mdPass");
        accountManager.callLogin("userName", "mdPass");

        when(serverMock.getBalance(sessionNumber)).thenReturn(new ServerResponse(ServerResponse.SUCCESS, balance));
        AccountManagerResponse getBalanceResult = accountManager.getBalance("userName", sessionNumber);
        assertEquals(AccountManagerResponse.SUCCEED, getBalanceResult.code);
        assertEquals(balance, getBalanceResult.response);

        when(serverMock.deposit(sessionNumber, amount)).thenReturn(new ServerResponse(ServerResponse.SUCCESS, (Double)getBalanceResult.response + amount));
        AccountManagerResponse result = accountManager.deposit("userName", sessionNumber, amount);
        assertEquals(AccountManagerResponse.SUCCEED, result.code);
        assertEquals(balance + amount, result.response);

        when(serverMock.logout(sessionNumber)).thenReturn(new ServerResponse(ServerResponse.SUCCESS, sessionNumber));
        AccountManagerResponse resultAfterLogout = accountManager.callLogout("userName", sessionNumber);
        assertEquals(AccountManagerResponse.SUCCEED_RESPONSE, resultAfterLogout);
    }

    @Test
    void depositNotLoggedInTable() {
        AccountManagerResponse result = accountManager.deposit("userName", sessionNumber, amount);
        assertEquals(AccountManagerResponse.NOT_LOGGED_RESPONSE, result);
    }

    @Test
    void depositNotLogged() {
        when(serverMock.login("userName", "mdPass")).thenReturn(new ServerResponse(ServerResponse.SUCCESS, sessionNumber));
        when(accountManager.makeSecure(anyString())).thenReturn("mdPass");
        accountManager.callLogin("userName", "mdPass");

        when(serverMock.deposit(sessionNumber, amount)).thenReturn(new ServerResponse(ServerResponse.NOT_LOGGED, null));
        AccountManagerResponse result = accountManager.deposit("userName", sessionNumber, amount);
        assertEquals(AccountManagerResponse.NOT_LOGGED_RESPONSE, result);

        when(serverMock.logout(sessionNumber)).thenReturn(new ServerResponse(ServerResponse.SUCCESS, sessionNumber));
        AccountManagerResponse resultAfterLogout = accountManager.callLogout("userName", sessionNumber);
        assertEquals(AccountManagerResponse.SUCCEED_RESPONSE, resultAfterLogout);
    }

    @Test
    void depositNotDouble() {
        when(serverMock.login("userName", "mdPass")).thenReturn(new ServerResponse(ServerResponse.SUCCESS, sessionNumber));
        when(accountManager.makeSecure(anyString())).thenReturn("mdPass");
        accountManager.callLogin("userName", "mdPass");

        when(serverMock.getBalance(sessionNumber)).thenReturn(new ServerResponse(ServerResponse.SUCCESS, balance));
        AccountManagerResponse getBalanceResult = accountManager.getBalance("userName", sessionNumber);
        assertEquals(AccountManagerResponse.SUCCEED, getBalanceResult.code);
        assertEquals(balance, getBalanceResult.response);

        int amount = 100;
        when(serverMock.deposit(sessionNumber, amount)).thenReturn(new ServerResponse(ServerResponse.SUCCESS, ((Double)getBalanceResult.response).intValue() + amount));
        AccountManagerResponse result = accountManager.deposit("userName", sessionNumber, amount);
        assertEquals(AccountManagerResponse.UNDEFINED_ERROR_RESPONSE, result);

        when(serverMock.logout(sessionNumber)).thenReturn(new ServerResponse(ServerResponse.SUCCESS, sessionNumber));
        AccountManagerResponse resultAfterLogout = accountManager.callLogout("userName", sessionNumber);
        assertEquals(AccountManagerResponse.SUCCEED_RESPONSE, resultAfterLogout);
    }

    @Test
    void depositNull() {
        when(serverMock.login("userName", "mdPass")).thenReturn(new ServerResponse(ServerResponse.SUCCESS, sessionNumber));
        when(accountManager.makeSecure(anyString())).thenReturn("mdPass");
        accountManager.callLogin("userName", "mdPass");

        when(serverMock.deposit(sessionNumber, amount)).thenReturn(new ServerResponse(ServerResponse.SUCCESS, null));
        AccountManagerResponse result = accountManager.deposit("userName", sessionNumber, amount);
        assertEquals(AccountManagerResponse.UNDEFINED_ERROR_RESPONSE, result);

        when(serverMock.logout(sessionNumber)).thenReturn(new ServerResponse(ServerResponse.SUCCESS, sessionNumber));
        AccountManagerResponse resultAfterLogout = accountManager.callLogout("userName", sessionNumber);
        assertEquals(AccountManagerResponse.SUCCEED_RESPONSE, resultAfterLogout);
    }

    @Test
    void depositIncorrectSession() {
        when(serverMock.login("userName", "mdPass")).thenReturn(new ServerResponse(ServerResponse.SUCCESS, sessionNumber));
        when(accountManager.makeSecure(anyString())).thenReturn("mdPass");
        accountManager.callLogin("userName", "mdPass");

        AccountManagerResponse result = accountManager.deposit("userName", 2L, amount);
        assertEquals(AccountManagerResponse.INCORRECT_SESSION_RESPONSE, result);

        when(serverMock.logout(sessionNumber)).thenReturn(new ServerResponse(ServerResponse.SUCCESS, sessionNumber));
        AccountManagerResponse resultAfterLogout = accountManager.callLogout("userName", sessionNumber);
        assertEquals(AccountManagerResponse.SUCCEED_RESPONSE, resultAfterLogout);
    }

    @Test
    void depositIncorrect() {
        when(serverMock.login("userName", "mdPass")).thenReturn(new ServerResponse(ServerResponse.SUCCESS, sessionNumber));
        when(accountManager.makeSecure(anyString())).thenReturn("mdPass");
        accountManager.callLogin("userName", "mdPass");

        when(serverMock.deposit(sessionNumber, amount)).thenReturn(new ServerResponse(ServerResponse.UNDEFINED_ERROR, null));
        AccountManagerResponse result = accountManager.deposit("userName", sessionNumber, amount);
        assertEquals(AccountManagerResponse.UNDEFINED_ERROR_RESPONSE, result);

        when(serverMock.logout(sessionNumber)).thenReturn(new ServerResponse(ServerResponse.SUCCESS, sessionNumber));
        AccountManagerResponse resultAfterLogout = accountManager.callLogout("userName", sessionNumber);
        assertEquals(AccountManagerResponse.SUCCEED_RESPONSE, resultAfterLogout);
    }

    //-------------------------------------------------------------
    // getBalance
    @Test
    void getBalanceSuccess() {
        when(serverMock.login("userName", "mdPass")).thenReturn(new ServerResponse(ServerResponse.SUCCESS, sessionNumber));
        when(accountManager.makeSecure(anyString())).thenReturn("mdPass");
        accountManager.callLogin("userName", "mdPass");

        when(serverMock.getBalance(sessionNumber)).thenReturn(new ServerResponse(ServerResponse.SUCCESS, balance));
        AccountManagerResponse result = accountManager.getBalance("userName", sessionNumber);
        assertEquals(AccountManagerResponse.SUCCEED, result.code);
        assertEquals(balance, result.response);

        when(serverMock.logout(sessionNumber)).thenReturn(new ServerResponse(ServerResponse.SUCCESS, sessionNumber));
        AccountManagerResponse resultAfterLogout = accountManager.callLogout("userName", sessionNumber);
        assertEquals(AccountManagerResponse.SUCCEED_RESPONSE, resultAfterLogout);
    }

    @Test
    void getBalanceNotLoggedInTable() {
        AccountManagerResponse result = accountManager.getBalance("userName", sessionNumber);
        assertEquals(AccountManagerResponse.NOT_LOGGED_RESPONSE, result);
    }

    @Test
    void getBalanceNotLogged() {
        when(serverMock.login("userName", "mdPass")).thenReturn(new ServerResponse(ServerResponse.SUCCESS, sessionNumber));
        when(accountManager.makeSecure(anyString())).thenReturn("mdPass");
        accountManager.callLogin("userName", "mdPass");

        when(serverMock.getBalance(sessionNumber)).thenReturn(new ServerResponse(ServerResponse.NOT_LOGGED, null));
        AccountManagerResponse result = accountManager.getBalance("userName", sessionNumber);
        assertEquals(AccountManagerResponse.NOT_LOGGED_RESPONSE, result);

        when(serverMock.logout(sessionNumber)).thenReturn(new ServerResponse(ServerResponse.SUCCESS, sessionNumber));
        AccountManagerResponse resultAfterLogout = accountManager.callLogout("userName", sessionNumber);
        assertEquals(AccountManagerResponse.SUCCEED_RESPONSE, resultAfterLogout);
    }

    @Test
    void getBalanceNotDouble() {
        when(serverMock.login("userName", "mdPass")).thenReturn(new ServerResponse(ServerResponse.SUCCESS, sessionNumber));
        when(accountManager.makeSecure(anyString())).thenReturn("mdPass");
        accountManager.callLogin("userName", "mdPass");

        int balance = 100;
        when(serverMock.getBalance(sessionNumber)).thenReturn(new ServerResponse(ServerResponse.SUCCESS, balance));
        AccountManagerResponse result = accountManager.getBalance("userName", sessionNumber);
        assertEquals(AccountManagerResponse.UNDEFINED_ERROR_RESPONSE, result);

        when(serverMock.logout(sessionNumber)).thenReturn(new ServerResponse(ServerResponse.SUCCESS, sessionNumber));
        AccountManagerResponse resultAfterLogout = accountManager.callLogout("userName", sessionNumber);
        assertEquals(AccountManagerResponse.SUCCEED_RESPONSE, resultAfterLogout);
    }

    @Test
    void getBalanceNull() {
        when(serverMock.login("userName", "mdPass")).thenReturn(new ServerResponse(ServerResponse.SUCCESS, sessionNumber));
        when(accountManager.makeSecure(anyString())).thenReturn("mdPass");
        accountManager.callLogin("userName", "mdPass");

        when(serverMock.getBalance(sessionNumber)).thenReturn(new ServerResponse(ServerResponse.SUCCESS, null));
        AccountManagerResponse result = accountManager.getBalance("userName", sessionNumber);
        assertEquals(AccountManagerResponse.UNDEFINED_ERROR_RESPONSE, result);

        when(serverMock.logout(sessionNumber)).thenReturn(new ServerResponse(ServerResponse.SUCCESS, sessionNumber));
        AccountManagerResponse resultAfterLogout = accountManager.callLogout("userName", sessionNumber);
        assertEquals(AccountManagerResponse.SUCCEED_RESPONSE, resultAfterLogout);
    }

    @Test
    void getBalanceIncorrectSession() {
        when(serverMock.login("userName", "mdPass")).thenReturn(new ServerResponse(ServerResponse.SUCCESS, sessionNumber));
        when(accountManager.makeSecure(anyString())).thenReturn("mdPass");
        accountManager.callLogin("userName", "mdPass");

        AccountManagerResponse result = accountManager.getBalance("userName", 2L);
        assertEquals(AccountManagerResponse.INCORRECT_SESSION_RESPONSE, result);

        when(serverMock.logout(sessionNumber)).thenReturn(new ServerResponse(ServerResponse.SUCCESS, sessionNumber));
        AccountManagerResponse resultAfterLogout = accountManager.callLogout("userName", sessionNumber);
        assertEquals(AccountManagerResponse.SUCCEED_RESPONSE, resultAfterLogout);
    }

    @Test
    void getBalanceIncorrect() {
        when(serverMock.login("userName", "mdPass")).thenReturn(new ServerResponse(ServerResponse.SUCCESS, sessionNumber));
        when(accountManager.makeSecure(anyString())).thenReturn("mdPass");
        accountManager.callLogin("userName", "mdPass");

        when(serverMock.getBalance(sessionNumber)).thenReturn(new ServerResponse(ServerResponse.UNDEFINED_ERROR, null));
        AccountManagerResponse result = accountManager.getBalance("userName", sessionNumber);
        assertEquals(AccountManagerResponse.UNDEFINED_ERROR_RESPONSE, result);

        when(serverMock.logout(sessionNumber)).thenReturn(new ServerResponse(ServerResponse.SUCCESS, sessionNumber));
        AccountManagerResponse resultAfterLogout = accountManager.callLogout("userName", sessionNumber);
        assertEquals(AccountManagerResponse.SUCCEED_RESPONSE, resultAfterLogout);
    }

    //-------------------------------------------------------------
    // FIRST SCENARIO
    @Test
    void firstScenario() {
        // Первая попытка входа
        when(serverMock.login("userName", "mdPass")).thenReturn(new ServerResponse(ServerResponse.ALREADY_LOGGED, sessionNumber));
        when(accountManager.makeSecure(anyString())).thenReturn("mdPass");
        AccountManagerResponse result1 = accountManager.callLogin("userName", "mdPass");
        assertEquals(AccountManagerResponse.ACCOUNT_MANAGER_RESPONSE, result1);

        // Вторая попытка входа
        when(serverMock.login("userName", "mdPass")).thenReturn(new ServerResponse(ServerResponse.NO_USER_INCORRECT_PASSWORD, sessionNumber));
        when(accountManager.makeSecure(anyString())).thenReturn("mdPass");
        AccountManagerResponse result2 = accountManager.callLogin("userName", "mdPass");
        assertEquals(AccountManagerResponse.NO_USER_INCORRECT_PASSWORD_RESPONSE, result2);

        // Успех, мы зашли в аккаунт
        when(serverMock.login("userName", "mdPass")).thenReturn(new ServerResponse(ServerResponse.SUCCESS, sessionNumber));
        when(accountManager.makeSecure(anyString())).thenReturn("mdPass");
        AccountManagerResponse resultFinal = accountManager.callLogin("userName", "mdPass");
        assertEquals(AccountManagerResponse.SUCCEED, resultFinal.code);
        assertEquals(sessionNumber, resultFinal.response);

        // Внесение 100 единиц
        when(serverMock.getBalance(sessionNumber)).thenReturn(new ServerResponse(ServerResponse.SUCCESS, balance));
        AccountManagerResponse getBalanceResult = accountManager.getBalance("userName", sessionNumber);
        assertEquals(AccountManagerResponse.SUCCEED, getBalanceResult.code);
        assertEquals(balance, getBalanceResult.response);

        when(serverMock.deposit(sessionNumber, amount)).thenReturn(new ServerResponse(ServerResponse.SUCCESS, (Double)getBalanceResult.response + amount));
        AccountManagerResponse result = accountManager.deposit("userName", sessionNumber, amount);
        assertEquals(AccountManagerResponse.SUCCEED, result.code);
        assertEquals(balance + amount, result.response);
    }

    //-------------------------------------------------------------
    // SECOND SCENARIO
    @Test
    void secondScenario() {
        // Вход в аккаунт
        when(serverMock.login("userName", "mdPass")).thenReturn(new ServerResponse(ServerResponse.SUCCESS, sessionNumber));
        when(accountManager.makeSecure(anyString())).thenReturn("mdPass");
        AccountManagerResponse resultFinal = accountManager.callLogin("userName", "mdPass");
        assertEquals(AccountManagerResponse.SUCCEED, resultFinal.code);
        assertEquals(sessionNumber, resultFinal.response);

        // Снятие 50, нет денег
        when(serverMock.withdraw(sessionNumber, 50D)).thenReturn(new ServerResponse(ServerResponse.NO_MONEY, 0D));
        AccountManagerResponse withdrawNoMoney = accountManager.withdraw("userName", sessionNumber, 50D);
        assertEquals(AccountManagerResponse.NO_MONEY_RESPONSE, withdrawNoMoney);

        // Запрос баланса
        when(serverMock.getBalance(sessionNumber)).thenReturn(new ServerResponse(ServerResponse.SUCCESS, 0D));
        AccountManagerResponse getBalanceResult = accountManager.getBalance("userName", sessionNumber);
        assertEquals(AccountManagerResponse.SUCCEED, getBalanceResult.code);
        assertEquals(0D, getBalanceResult.response);

        // Внесение 100
        when(serverMock.deposit(sessionNumber, 100D)).thenReturn(new ServerResponse(ServerResponse.SUCCESS, (Double)getBalanceResult.response + 100D));
        AccountManagerResponse deposit100 = accountManager.deposit("userName", sessionNumber, 100D);
        assertEquals(AccountManagerResponse.SUCCEED, deposit100.code);
        assertEquals(0D + 100D, deposit100.response);

        // Снятие 50, некорректный номер сессии
        AccountManagerResponse withdraw50Incorrect = accountManager.withdraw("userName", 2L, 50D);
        assertEquals(AccountManagerResponse.INCORRECT_SESSION_RESPONSE, withdraw50Incorrect);

        // Снятие 50
        when(serverMock.getBalance(sessionNumber)).thenReturn(new ServerResponse(ServerResponse.SUCCESS, balance));
        AccountManagerResponse balanceAfterDeposit = accountManager.getBalance("userName", sessionNumber);
        assertEquals(AccountManagerResponse.SUCCEED, balanceAfterDeposit.code);
        assertEquals(balance, balanceAfterDeposit.response);

        when(serverMock.withdraw(sessionNumber, 50D)).thenReturn(new ServerResponse(ServerResponse.SUCCESS, (Double)balanceAfterDeposit.response - 50D));
        AccountManagerResponse result = accountManager.withdraw("userName", sessionNumber, 50D);
        assertEquals(AccountManagerResponse.SUCCEED, result.code);
        assertEquals(100D - 50D, result.response);

        // Выход из аккаунта
        when(serverMock.logout(sessionNumber)).thenReturn(new ServerResponse(ServerResponse.SUCCESS, sessionNumber));
        AccountManagerResponse resultAfterLogout = accountManager.callLogout("userName", sessionNumber);
        assertEquals(AccountManagerResponse.SUCCEED_RESPONSE, resultAfterLogout);
    }
}