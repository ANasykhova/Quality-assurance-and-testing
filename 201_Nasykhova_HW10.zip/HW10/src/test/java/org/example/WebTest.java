package org.example;

import static org.junit.jupiter.api.Assertions.*;

import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.opentest4j.AssertionFailedError;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.net.HttpURLConnection;
import java.net.URI;
import java.net.URL;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.util.concurrent.TimeUnit;

public class WebTest {
    private WebDriver driver;
    private String baseUrl;
    private boolean acceptNextAlert = true;
    private StringBuffer verificationErrors = new StringBuffer();
    //private final String sessionID = "v4RPc3rBRxTV2GTPT2j0";

    @BeforeClass(alwaysRun = true)
    public void setUp() throws Exception {
        System.setProperty("web-driver.chrome.driver", "D:\\chromedriver.exe");
        driver = new ChromeDriver();
        baseUrl = "https://www.google.com/";
        driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
    }

    //===========================================================
    // РЕЖИМ ПЕРЕМЕЩЕНИЕ

    // 1) Перемещение в пределах [0;20) (возможность переместиться на 1, проверка на правый ограничитель)
    // Сценарий: вход в сессию, (нажатие на стрелку, ожидание 5 секунд, переход на 1) до 19, остановка, выход из сессии
    @Test
    public void moveRight() throws Exception {
        // Login
        driver.get("http://ruswizard.ddns.net:8091/");
        waitButton(By.xpath("//input[@value='Login']")).click();

        try {
            int count = driver.findElements(By.xpath("//img[(@id=\"arrowRight\") and not (contains(@class, 'hidden'))]")).size();

            while (count == 1) {
                waitButton(By.id("arrowRight")).click();
                waitTimer();
                count = driver.findElements(By.xpath("//img[(@id=\"arrowRight\") and not (contains(@class, 'hidden'))]")).size();
            }
            // Вышли из цикла, значит, дальше идти нельзя

            int place = Integer.parseInt(driver.findElement(By.id("place")).getAttribute("innerHTML").split("\\[")[1].split("]")[0]);
            assertEquals(19, place);
        } finally {
            // Logout
            WebElement logout = driver.findElement(By.id("logout"));
            if (logout != null)
                logout.click();
        }
    }

    // 2) Перемещение в пределах (-20;0] (возможность переместиться на 1, проверка на левый ограничитель)
    // Сценарий: вход в сессию, (нажатие на стрелку, ожидание 5 секунд, переход на 1) до -19, остановка, выход из сессии
    @Test
    public void moveLeft() throws Exception {
        // Login
        driver.get("http://ruswizard.ddns.net:8091/");
        waitButton(By.xpath("//input[@value='Login']")).click();

        try {
            int count = driver.findElements(By.xpath("//img[(@id=\"arrowLeft\") and not (contains(@class, 'hidden'))]")).size();

            while (count == 1) {
                waitButton(By.id("arrowLeft")).click();
                waitTimer();
                count = driver.findElements(By.xpath("//img[(@id=\"arrowLeft\") and not (contains(@class, 'hidden'))]")).size();
            }
            // Вышли из цикла, значит, дальше идти нельзя

            int place = Integer.parseInt(driver.findElement(By.id("place")).getAttribute("innerHTML").split("\\[")[1].split("]")[0]);
            assertEquals(-19, place);
        } finally {
            // Logout
            WebElement logout = driver.findElement(By.id("logout"));
            if (logout != null)
                logout.click();
        }
    }

    // 3) Наличие объектов в пределах [-50;50]
    // Объеты есть! Перед запуском рекомендуется обновить sessionID
    @Test
    public void moveRight50() throws Exception {
        String sessionID = "Vf73ttzKDfpKXfEFmZvE";
        URL url = new URL("http://ruswizard.ddns.net:7852/variables/location/" + sessionID);

        try {
            HttpClient client = HttpClient.newHttpClient();
            HttpRequest request = HttpRequest.newBuilder()
                    .uri(URI.create(String.valueOf(url)))
                    .POST(HttpRequest.BodyPublishers.ofString(String.valueOf(-50)))
                    .build();
            HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());

            int step = -50;

            while (step < 50) {
                client = HttpClient.newHttpClient();
                request = HttpRequest.newBuilder()
                        .uri(URI.create(String.valueOf(url)))
                        .POST(HttpRequest.BodyPublishers.ofString(String.valueOf(1)))
                        .build();
                response = client.send(request, HttpResponse.BodyHandlers.ofString());
                assertEquals(200, response.statusCode());

                driver.get("http://ruswizard.ddns.net:8091/");
                driver.findElement(By.id("sessionId")).clear();
                driver.findElement(By.id("sessionId")).sendKeys(sessionID);
                driver.findElement(By.xpath("//input[@value='Login']")).click();

                WebDriverWait wait = new WebDriverWait(driver, Duration.ofHours(1));
                wait.until(ExpectedConditions.attributeContains(By.id("status"), "innerHTML", "Online"));

                String desc = driver.findElement(By.id("text")).getAttribute("innerHTML");
                System.out.println(desc);
                assertTrue(desc.contains("Безмятежное синее море"));

                WebElement logout = driver.findElement(By.id("logout"));
                if (logout != null)
                    logout.click();

                step++;
            }
        } catch (AssertionFailedError ex) {
            System.out.println("На отрезке [-50;50] есть запрещенные объекты");
            WebElement logout = driver.findElement(By.id("logout"));
            if (logout != null)
                logout.click();
        }
    }

    //===========================================================
    // РЕЖИМ ТОРГОВЛЯ
    //===========================================================
    // ПОКУПКА

    // 1.1) Покупка возможна
    // Сценарий: логин, переход в док, проверки:
    // 1. item1cnt > 0 (регулируем мы => выполняется всегда)
    // 2. item1buy > 0
    // 3. dockcnt-1 >= item1cnt
    // 4. money > item1buy * item1cnt
    // 5. cargoInfo + widht-1 * item1cnt <= 2000
    // в случае выполнения системы - покупка, проверки:
    // 1. new item1buy > item1buy
    // 2. new item1sell < item1sell
    // 3. new_on_board = on_board + 2
    // 4. new_in_port = in_port - 2
    // 5. new_cargoInfo = cargoInfo + weight * count
    // 6. new_money = money - price_buy * count
    // 7. new_moneyDock = moneyDock + price_buy * count
    // выход из дока, логаут
    @Test
    public void positiveBuy() throws Exception {
        // Login
        driver.get("http://ruswizard.ddns.net:8091/");
        waitButton(By.xpath("//input[@value='Login']")).click();

        try {
            waitButton(By.linkText("Зайти в док")).click();

            // Получаем все значения
            double price_buy = Double.parseDouble(driver.findElement(By.id("item1buy")).getAttribute("value").split("\\[")[1].split("]")[0]);
            double price_sell = Double.parseDouble(driver.findElement(By.id("item1sell")).getAttribute("value").split("\\[")[1].split("]")[0]);

            double weight = Double.parseDouble(driver.findElement(By.id("widht-1")).getAttribute("innerHTML"));
            double in_port = Double.parseDouble(driver.findElement(By.id("dockcnt-1")).getAttribute("innerHTML"));
            double on_board = Double.parseDouble(driver.findElement(By.id("shopcnt-1")).getAttribute("innerHTML"));
            double money = Double.parseDouble(driver.findElement(By.id("money")).getAttribute("innerHTML"));
            double moneyDock = Double.parseDouble(driver.findElement(By.id("moneyDock")).getAttribute("innerHTML"));
            double cargoInfo = Double.parseDouble(driver.findElement(By.id("cargoInfo")).getAttribute("innerHTML").split("/")[0]);

            double count = 2.0;
            // Проверки
            assertTrue(price_buy > 0);
            assertTrue(in_port >= count);
            assertTrue(money > price_buy * count);
            assertTrue(cargoInfo + weight * count <= 2000);

            waitButton(By.id("item1cnt")).click();
            driver.findElement(By.id("item1cnt")).clear();
            driver.findElement(By.id("item1cnt")).sendKeys(Double.toString(count));

            waitButton(By.id("item1buy")).click();

            WebDriverWait wait = new WebDriverWait(driver, Duration.ofHours(1));
            wait.until(ExpectedConditions.attributeContains(By.id("status"), "innerHTML", "Online"));

            // Получаем все значения
            double new_price_buy = Double.parseDouble(driver.findElement(By.id("item1buy")).getAttribute("value").split("\\[")[1].split("]")[0]);
            double new_price_sell = Double.parseDouble(driver.findElement(By.id("item1sell")).getAttribute("value").split("\\[")[1].split("]")[0]);

            double new_in_port = Double.parseDouble(driver.findElement(By.id("dockcnt-1")).getAttribute("innerHTML"));
            double new_on_board = Double.parseDouble(driver.findElement(By.id("shopcnt-1")).getAttribute("innerHTML"));
            double new_money = Double.parseDouble(driver.findElement(By.id("money")).getAttribute("innerHTML"));
            double new_moneyDock = Double.parseDouble(driver.findElement(By.id("moneyDock")).getAttribute("innerHTML"));
            double new_cargoInfo = Double.parseDouble(driver.findElement(By.id("cargoInfo")).getAttribute("innerHTML").split("/")[0]);

            // Проверки
            assertTrue(new_price_buy > price_buy);
            assertTrue(new_price_sell < price_sell);
            assertEquals(new_on_board, on_board + 2);
            assertEquals(new_in_port, in_port - 2);
            assertEquals(new_cargoInfo, cargoInfo + weight * count);
            assertEquals(new_money, money - price_buy * count);
            assertEquals(new_moneyDock, moneyDock + price_buy * count);

            waitButton(By.linkText("Вернуться в море")).click();
        } finally {
            // Logout
            WebElement logout = driver.findElement(By.id("logout"));
            if (logout != null)
                logout.click();
        }
    }

    // 1.2) Покупка не возможна
    // item1cnt < 0
    // Сценарий: логин, переход в док, попытка купить отрицательное число товара, проверка, что ничего не изменилось, выход из дока, логаут
    // Поле не дает ввести отрицательное число, поэтому будет куплено abs(count) количество товара
    @Test
    public void negativeCountBuy() throws Exception {
        // Login
        driver.get("http://ruswizard.ddns.net:8091/");
        waitButton(By.xpath("//input[@value='Login']")).click();

        try {
            waitButton(By.linkText("Зайти в док")).click();

            // Получаем все значения
            double price_buy = Double.parseDouble(driver.findElement(By.id("item1buy")).getAttribute("value").split("\\[")[1].split("]")[0]);
            double price_sell = Double.parseDouble(driver.findElement(By.id("item1sell")).getAttribute("value").split("\\[")[1].split("]")[0]);
            double weight = Double.parseDouble(driver.findElement(By.id("widht-1")).getAttribute("innerHTML"));
            double in_port = Double.parseDouble(driver.findElement(By.id("dockcnt-1")).getAttribute("innerHTML"));
            double on_board = Double.parseDouble(driver.findElement(By.id("shopcnt-1")).getAttribute("innerHTML"));
            double money = Double.parseDouble(driver.findElement(By.id("money")).getAttribute("innerHTML"));
            double moneyDock = Double.parseDouble(driver.findElement(By.id("moneyDock")).getAttribute("innerHTML"));
            double cargoInfo = Double.parseDouble(driver.findElement(By.id("cargoInfo")).getAttribute("innerHTML").split("/")[0]);

            double count = -2.0;
            // Проверки, что остальные критерии покупки в норме
            assertTrue(price_buy > 0);
            assertTrue(in_port >= count);
            assertTrue(money > price_buy * count);
            assertTrue(cargoInfo + weight * count <= 2000);

            waitButton(By.id("item1cnt")).click();
            driver.findElement(By.id("item1cnt")).clear();
            driver.findElement(By.id("item1cnt")).sendKeys("-2");

            waitButton(By.id("item1buy")).click();

            WebDriverWait wait = new WebDriverWait(driver, Duration.ofHours(1));
            wait.until(ExpectedConditions.attributeContains(By.id("status"), "innerHTML", "Online"));

            // Получаем все значения
            double new_price_buy = Double.parseDouble(driver.findElement(By.id("item1buy")).getAttribute("value").split("\\[")[1].split("]")[0]);
            double new_price_sell = Double.parseDouble(driver.findElement(By.id("item1sell")).getAttribute("value").split("\\[")[1].split("]")[0]);
            double new_weight = Double.parseDouble(driver.findElement(By.id("widht-1")).getAttribute("innerHTML"));
            double new_in_port = Double.parseDouble(driver.findElement(By.id("dockcnt-1")).getAttribute("innerHTML"));
            double new_on_board = Double.parseDouble(driver.findElement(By.id("shopcnt-1")).getAttribute("innerHTML"));
            double new_money = Double.parseDouble(driver.findElement(By.id("money")).getAttribute("innerHTML"));
            double new_moneyDock = Double.parseDouble(driver.findElement(By.id("moneyDock")).getAttribute("innerHTML"));
            double new_cargoInfo = Double.parseDouble(driver.findElement(By.id("cargoInfo")).getAttribute("innerHTML").split("/")[0]);

            // Проверки: ничего не изменилось
            assertEquals(new_price_buy, price_buy);
            assertEquals(new_price_sell, price_sell);
            assertEquals(new_on_board, on_board);
            assertEquals(new_in_port, in_port);
            assertEquals(new_cargoInfo, cargoInfo);
            assertEquals(new_money, money);
            assertEquals(new_moneyDock, moneyDock);

            waitButton(By.linkText("Вернуться в море")).click();
        } catch (AssertionFailedError ex) {
            waitButton(By.linkText("Вернуться в море")).click();
        } finally {
            // Logout
            WebElement logout = driver.findElement(By.id("logout"));
            if (logout != null)
                logout.click();
        }
    }

    // 1.3) Покупка не возможна
    // dockcnt-1 < item1cnt
    // Сценарий: логин, переход в док, попытка купить отрицательное число товара, проверка, что ничего не изменилось, выход из дока, логаут
    @Test
    public void countMoreDockCountBuy() throws Exception {
        // Login
        driver.get("http://ruswizard.ddns.net:8091/");
        waitButton(By.xpath("//input[@value='Login']")).click();

        try {
            waitButton(By.linkText("Зайти в док")).click();

            // Получаем все значения
            double price_buy = Double.parseDouble(driver.findElement(By.id("item1buy")).getAttribute("value").split("\\[")[1].split("]")[0]);
            double price_sell = Double.parseDouble(driver.findElement(By.id("item1sell")).getAttribute("value").split("\\[")[1].split("]")[0]);
            double weight = Double.parseDouble(driver.findElement(By.id("widht-1")).getAttribute("innerHTML"));
            double in_port = Double.parseDouble(driver.findElement(By.id("dockcnt-1")).getAttribute("innerHTML"));
            double on_board = Double.parseDouble(driver.findElement(By.id("shopcnt-1")).getAttribute("innerHTML"));
            double money = Double.parseDouble(driver.findElement(By.id("money")).getAttribute("innerHTML"));
            double moneyDock = Double.parseDouble(driver.findElement(By.id("moneyDock")).getAttribute("innerHTML"));
            double cargoInfo = Double.parseDouble(driver.findElement(By.id("cargoInfo")).getAttribute("innerHTML").split("/")[0]);

            double count = in_port + 1;
            // Проверки, что остальные критерии покупки в норме
            assertTrue(price_buy > 0);
            assertTrue(money > price_buy * count);

            waitButton(By.id("item1cnt")).click();
            driver.findElement(By.id("item1cnt")).clear();
            driver.findElement(By.id("item1cnt")).sendKeys(Double.toString(count));

            waitButton(By.id("item1buy")).click();

            WebDriverWait wait = new WebDriverWait(driver, Duration.ofHours(1));
            wait.until(ExpectedConditions.attributeContains(By.id("status"), "innerHTML", "Online"));

            // Получаем все значения
            double new_price_buy = Double.parseDouble(driver.findElement(By.id("item1buy")).getAttribute("value").split("\\[")[1].split("]")[0]);
            double new_price_sell = Double.parseDouble(driver.findElement(By.id("item1sell")).getAttribute("value").split("\\[")[1].split("]")[0]);
            double new_weight = Double.parseDouble(driver.findElement(By.id("widht-1")).getAttribute("innerHTML"));
            double new_in_port = Double.parseDouble(driver.findElement(By.id("dockcnt-1")).getAttribute("innerHTML"));
            double new_on_board = Double.parseDouble(driver.findElement(By.id("shopcnt-1")).getAttribute("innerHTML"));
            double new_money = Double.parseDouble(driver.findElement(By.id("money")).getAttribute("innerHTML"));
            double new_moneyDock = Double.parseDouble(driver.findElement(By.id("moneyDock")).getAttribute("innerHTML"));
            double new_cargoInfo = Double.parseDouble(driver.findElement(By.id("cargoInfo")).getAttribute("innerHTML").split("/")[0]);

            // Проверки: ничего не изменилось
            assertEquals(new_price_buy, price_buy);
            assertEquals(new_price_sell, price_sell);
            assertEquals(new_on_board, on_board);
            assertEquals(new_in_port, in_port);
            assertEquals(new_cargoInfo, cargoInfo);
            assertEquals(new_money, money);
            assertEquals(new_moneyDock, moneyDock);

            waitButton(By.linkText("Вернуться в море")).click();
        } finally {
            // Logout
            WebElement logout = driver.findElement(By.id("logout"));
            if (logout != null)
                logout.click();
        }
    }

    // 1.4) Покупка не возможна
    // money < item1buy * item1cnt
    // Сценарий: логин, переход в док, попытка купить отрицательное число товара, проверка, что ничего не изменилось, выход из дока, логаут
    @Test
    public void moneyLessBuyAmount() throws Exception {
        // Login
        driver.get("http://ruswizard.ddns.net:8091/");
        waitButton(By.xpath("//input[@value='Login']")).click();

        try {
            waitButton(By.linkText("Зайти в док")).click();

            // Получаем все значения
            double price_buy = Double.parseDouble(driver.findElement(By.id("item1buy")).getAttribute("value").split("\\[")[1].split("]")[0]);
            double price_sell = Double.parseDouble(driver.findElement(By.id("item1sell")).getAttribute("value").split("\\[")[1].split("]")[0]);
            double weight = Double.parseDouble(driver.findElement(By.id("widht-1")).getAttribute("innerHTML"));
            double in_port = Double.parseDouble(driver.findElement(By.id("dockcnt-1")).getAttribute("innerHTML"));
            double on_board = Double.parseDouble(driver.findElement(By.id("shopcnt-1")).getAttribute("innerHTML"));
            double money = Double.parseDouble(driver.findElement(By.id("money")).getAttribute("innerHTML"));
            double moneyDock = Double.parseDouble(driver.findElement(By.id("moneyDock")).getAttribute("innerHTML"));
            double cargoInfo = Double.parseDouble(driver.findElement(By.id("cargoInfo")).getAttribute("innerHTML").split("/")[0]);

            double count = in_port;
            while (money > count * price_buy) {
                waitButton(By.id("item1cnt")).click();
                driver.findElement(By.id("item1cnt")).clear();
                driver.findElement(By.id("item1cnt")).sendKeys(Double.toString(count));

                waitButton(By.id("item1buy")).click();

                WebDriverWait wait = new WebDriverWait(driver, Duration.ofHours(1));
                wait.until(ExpectedConditions.attributeContains(By.id("status"), "innerHTML", "Online"));

                waitButton(By.id("item1cnt")).click();
                driver.findElement(By.id("item1cnt")).clear();
                driver.findElement(By.id("item1cnt")).sendKeys(Double.toString(count));

                waitButton(By.id("item1sell")).click();

                wait.until(ExpectedConditions.attributeContains(By.id("status"), "innerHTML", "Online"));

                money = Double.parseDouble(driver.findElement(By.id("money")).getAttribute("innerHTML"));
                price_buy = Double.parseDouble(driver.findElement(By.id("item1buy")).getAttribute("value").split("\\[")[1].split("]")[0]);
                price_sell = Double.parseDouble(driver.findElement(By.id("item1sell")).getAttribute("value").split("\\[")[1].split("]")[0]);
            }

            // Проверки, что остальные критерии покупки в норме
            assertTrue(price_buy > 0);
            assertTrue(in_port >= count);
            assertTrue(cargoInfo + weight * count < 2000);

            waitButton(By.id("item1cnt")).click();
            driver.findElement(By.id("item1cnt")).clear();
            driver.findElement(By.id("item1cnt")).sendKeys(Double.toString(count));

            waitButton(By.id("item1buy")).click();

            WebDriverWait wait = new WebDriverWait(driver, Duration.ofHours(1));
            wait.until(ExpectedConditions.attributeContains(By.id("status"), "innerHTML", "Online"));

            // Получаем все значения
            double new_price_buy = Double.parseDouble(driver.findElement(By.id("item1buy")).getAttribute("value").split("\\[")[1].split("]")[0]);
            double new_price_sell = Double.parseDouble(driver.findElement(By.id("item1sell")).getAttribute("value").split("\\[")[1].split("]")[0]);
            double new_weight = Double.parseDouble(driver.findElement(By.id("widht-1")).getAttribute("innerHTML"));
            double new_in_port = Double.parseDouble(driver.findElement(By.id("dockcnt-1")).getAttribute("innerHTML"));
            double new_on_board = Double.parseDouble(driver.findElement(By.id("shopcnt-1")).getAttribute("innerHTML"));
            double new_money = Double.parseDouble(driver.findElement(By.id("money")).getAttribute("innerHTML"));
            double new_moneyDock = Double.parseDouble(driver.findElement(By.id("moneyDock")).getAttribute("innerHTML"));
            double new_cargoInfo = Double.parseDouble(driver.findElement(By.id("cargoInfo")).getAttribute("innerHTML").split("/")[0]);

            // Проверки: ничего не изменилось
            assertEquals(new_price_buy, price_buy);
            assertEquals(new_price_sell, price_sell);
            assertEquals(new_on_board, on_board);
            assertEquals(new_in_port, in_port);
            assertEquals(new_cargoInfo, cargoInfo);
            assertEquals(new_money, money);
            assertEquals(new_moneyDock, moneyDock);

            waitButton(By.linkText("Вернуться в море")).click();
        } catch (AssertionFailedError ex) {
            waitButton(By.linkText("Вернуться в море")).click();
        } finally {
            // Logout
            WebElement logout = driver.findElement(By.id("logout"));
            if (logout != null)
                logout.click();
        }
    }

    // 1.5) Покупка не возможна
    // cargoInfo + widht-1 * item1cnt > 2000
    // Сценарий: логин, переход в док, попытка купить отрицательное число товара, проверка, что ничего не изменилось, выход из дока, логаут
    @Test
    public void notEnoughPlaceBuy() throws Exception {
        // Login
        driver.get("http://ruswizard.ddns.net:8091/");
        waitButton(By.xpath("//input[@value='Login']")).click();

        try {
            waitButton(By.linkText("Зайти в док")).click();

            // Получаем все значения
            double price_buy = Double.parseDouble(driver.findElement(By.id("item1buy")).getAttribute("value").split("\\[")[1].split("]")[0]);
            double price_sell = Double.parseDouble(driver.findElement(By.id("item1sell")).getAttribute("value").split("\\[")[1].split("]")[0]);
            double weight = Double.parseDouble(driver.findElement(By.id("widht-1")).getAttribute("innerHTML"));
            double in_port = Double.parseDouble(driver.findElement(By.id("dockcnt-1")).getAttribute("innerHTML"));
            double on_board = Double.parseDouble(driver.findElement(By.id("shopcnt-1")).getAttribute("innerHTML"));
            double money = Double.parseDouble(driver.findElement(By.id("money")).getAttribute("innerHTML"));
            double moneyDock = Double.parseDouble(driver.findElement(By.id("moneyDock")).getAttribute("innerHTML"));
            double cargoInfo = Double.parseDouble(driver.findElement(By.id("cargoInfo")).getAttribute("innerHTML").split("/")[0]);

            double count = (2000 - cargoInfo) / weight + 1;
            System.out.println(count);
            // Проверки, что остальные критерии покупки в норме
            assertTrue(count > 0);
            assertTrue(price_buy > 0);
            assertTrue(money > price_buy * count);

            waitButton(By.id("item1cnt")).click();
            driver.findElement(By.id("item1cnt")).clear();
            driver.findElement(By.id("item1cnt")).sendKeys(Double.toString(count));

            waitButton(By.id("item1buy")).click();

            WebDriverWait wait = new WebDriverWait(driver, Duration.ofHours(1));
            wait.until(ExpectedConditions.attributeContains(By.id("status"), "innerHTML", "Online"));

            // Получаем все значения
            double new_price_buy = Double.parseDouble(driver.findElement(By.id("item1buy")).getAttribute("value").split("\\[")[1].split("]")[0]);
            double new_price_sell = Double.parseDouble(driver.findElement(By.id("item1sell")).getAttribute("value").split("\\[")[1].split("]")[0]);
            double new_weight = Double.parseDouble(driver.findElement(By.id("widht-1")).getAttribute("innerHTML"));
            double new_in_port = Double.parseDouble(driver.findElement(By.id("dockcnt-1")).getAttribute("innerHTML"));
            double new_on_board = Double.parseDouble(driver.findElement(By.id("shopcnt-1")).getAttribute("innerHTML"));
            double new_money = Double.parseDouble(driver.findElement(By.id("money")).getAttribute("innerHTML"));
            double new_moneyDock = Double.parseDouble(driver.findElement(By.id("moneyDock")).getAttribute("innerHTML"));
            double new_cargoInfo = Double.parseDouble(driver.findElement(By.id("cargoInfo")).getAttribute("innerHTML").split("/")[0]);

            // Проверки: ничего не изменилось
            assertEquals(new_price_buy, price_buy);
            assertEquals(new_price_sell, price_sell);
            assertEquals(new_on_board, on_board);
            assertEquals(new_in_port, in_port);
            assertEquals(new_cargoInfo, cargoInfo);
            assertEquals(new_money, money);
            assertEquals(new_moneyDock, moneyDock);

            waitButton(By.linkText("Вернуться в море")).click();
        } finally {
            // Logout
            WebElement logout = driver.findElement(By.id("logout"));
            if (logout != null)
                logout.click();
        }
    }

    //===========================================================
    // РЕЖИМ ТОРГОВЛЯ
    //===========================================================
    // ПРОДАЖА

    // 1.1) Продажа возможна
    // Сценарий: логин, переход в док, проверки:
    // 1. item1cnt > 0 (регулируем мы => выполняется всегда)
    // 2. item1sell > 0
    // 3. shopcnt-1 >= item1cnt
    // 4. moneyDock > item1sell * item1cnt
    // в случае выполнения системы - покупка, проверки:
    // 1. new item1buy > item1buy
    // 2. new item1sell < item1sell
    // 3. new_on_board = on_board - count
    // 4. new_in_port = in_port + count
    // 5. new_cargoInfo = cargoInfo - weight * count
    // 7. new_money = money + price_sell * count
    // 8. new_moneyDock = moneyDock - price_sell * count
    // выход из дока, логаут
    @Test
    public void positiveSell() throws Exception {
        // Login
        driver.get("http://ruswizard.ddns.net:8091/");
        waitButton(By.xpath("//input[@value='Login']")).click();

        try {
            waitButton(By.linkText("Зайти в док")).click();

            double count = 2.0;
            waitButton(By.id("item1cnt")).click();
            driver.findElement(By.id("item1cnt")).clear();
            driver.findElement(By.id("item1cnt")).sendKeys(Double.toString(count));

            waitButton(By.id("item1buy")).click();

            WebDriverWait wait = new WebDriverWait(driver, Duration.ofHours(1));
            wait.until(ExpectedConditions.attributeContains(By.id("status"), "innerHTML", "Online"));

            // Получаем все значения
            double price_buy = Double.parseDouble(driver.findElement(By.id("item1buy")).getAttribute("value").split("\\[")[1].split("]")[0]);
            double price_sell = Double.parseDouble(driver.findElement(By.id("item1sell")).getAttribute("value").split("\\[")[1].split("]")[0]);
            double weight = Double.parseDouble(driver.findElement(By.id("widht-1")).getAttribute("innerHTML"));
            double in_port = Double.parseDouble(driver.findElement(By.id("dockcnt-1")).getAttribute("innerHTML"));
            double on_board = Double.parseDouble(driver.findElement(By.id("shopcnt-1")).getAttribute("innerHTML"));
            double money = Double.parseDouble(driver.findElement(By.id("money")).getAttribute("innerHTML"));
            double moneyDock = Double.parseDouble(driver.findElement(By.id("moneyDock")).getAttribute("innerHTML"));
            double cargoInfo = Double.parseDouble(driver.findElement(By.id("cargoInfo")).getAttribute("innerHTML").split("/")[0]);

            // Проверки
            assertTrue(price_sell > 0);
            assertTrue(on_board >= count);
            assertTrue(moneyDock > price_buy * count);

            waitButton(By.id("item1cnt")).click();
            driver.findElement(By.id("item1cnt")).clear();
            driver.findElement(By.id("item1cnt")).sendKeys(Double.toString(count));

            waitButton(By.id("item1sell")).click();

            wait.until(ExpectedConditions.attributeContains(By.id("status"), "innerHTML", "Online"));

            // Получаем все значения
            double new_price_buy = Double.parseDouble(driver.findElement(By.id("item1buy")).getAttribute("value").split("\\[")[1].split("]")[0]);
            double new_price_sell = Double.parseDouble(driver.findElement(By.id("item1sell")).getAttribute("value").split("\\[")[1].split("]")[0]);
            double new_in_port = Double.parseDouble(driver.findElement(By.id("dockcnt-1")).getAttribute("innerHTML"));
            double new_on_board = Double.parseDouble(driver.findElement(By.id("shopcnt-1")).getAttribute("innerHTML"));
            double new_money = Double.parseDouble(driver.findElement(By.id("money")).getAttribute("innerHTML"));
            double new_moneyDock = Double.parseDouble(driver.findElement(By.id("moneyDock")).getAttribute("innerHTML"));
            double new_cargoInfo = Double.parseDouble(driver.findElement(By.id("cargoInfo")).getAttribute("innerHTML").split("/")[0]);

            // Проверки
            assertTrue(new_price_buy > price_buy);
            assertTrue(new_price_sell < price_sell);
            assertEquals(new_on_board, on_board - count);
            assertEquals(new_in_port, in_port + count);
            assertEquals(new_cargoInfo, cargoInfo - weight * count);

            waitButton(By.linkText("Вернуться в море")).click();
        } finally {
            // Logout
            WebElement logout = driver.findElement(By.id("logout"));
            if (logout != null)
                logout.click();
        }
    }

    // 1.2) Продажа не возможна
    // item1cnt < 0
    // Сценарий: логин, переход в док, попытка купить отрицательное число товара, проверка, что ничего не изменилось, выход из дока, логаут
    // Поле не дает ввести отрицательное число, поэтому будет куплено abs(count) количество товара
    @Test
    public void negativeCountSell() throws Exception {
        // Login
        driver.get("http://ruswizard.ddns.net:8091/");
        waitButton(By.xpath("//input[@value='Login']")).click();

        try {
            waitButton(By.linkText("Зайти в док")).click();
            double count = 2.0;
            waitButton(By.id("item1cnt")).click();
            driver.findElement(By.id("item1cnt")).clear();
            driver.findElement(By.id("item1cnt")).sendKeys(Double.toString(count));

            waitButton(By.id("item1buy")).click();

            WebDriverWait wait = new WebDriverWait(driver, Duration.ofHours(1));
            wait.until(ExpectedConditions.attributeContains(By.id("status"), "innerHTML", "Online"));
            // Получаем все значения
            double price_buy = Double.parseDouble(driver.findElement(By.id("item1buy")).getAttribute("value").split("\\[")[1].split("]")[0]);
            double price_sell = Double.parseDouble(driver.findElement(By.id("item1sell")).getAttribute("value").split("\\[")[1].split("]")[0]);
            double weight = Double.parseDouble(driver.findElement(By.id("widht-1")).getAttribute("innerHTML"));
            double in_port = Double.parseDouble(driver.findElement(By.id("dockcnt-1")).getAttribute("innerHTML"));
            double on_board = Double.parseDouble(driver.findElement(By.id("shopcnt-1")).getAttribute("innerHTML"));
            double money = Double.parseDouble(driver.findElement(By.id("money")).getAttribute("innerHTML"));
            double moneyDock = Double.parseDouble(driver.findElement(By.id("moneyDock")).getAttribute("innerHTML"));
            double cargoInfo = Double.parseDouble(driver.findElement(By.id("cargoInfo")).getAttribute("innerHTML").split("/")[0]);

            // Проверки, что остальные критерии покупки в норме
            assertTrue(price_sell > 0);
            assertTrue(on_board >= count);
            assertTrue(moneyDock > price_sell * count);

            waitButton(By.id("item1cnt")).click();
            driver.findElement(By.id("item1cnt")).clear();
            driver.findElement(By.id("item1cnt")).sendKeys("-2");

            waitButton(By.id("item1buy")).click();

            wait.until(ExpectedConditions.attributeContains(By.id("status"), "innerHTML", "Online"));

            // Получаем все значения
            double new_price_buy = Double.parseDouble(driver.findElement(By.id("item1buy")).getAttribute("value").split("\\[")[1].split("]")[0]);
            double new_price_sell = Double.parseDouble(driver.findElement(By.id("item1sell")).getAttribute("value").split("\\[")[1].split("]")[0]);
            double new_weight = Double.parseDouble(driver.findElement(By.id("widht-1")).getAttribute("innerHTML"));
            double new_in_port = Double.parseDouble(driver.findElement(By.id("dockcnt-1")).getAttribute("innerHTML"));
            double new_on_board = Double.parseDouble(driver.findElement(By.id("shopcnt-1")).getAttribute("innerHTML"));
            double new_money = Double.parseDouble(driver.findElement(By.id("money")).getAttribute("innerHTML"));
            double new_moneyDock = Double.parseDouble(driver.findElement(By.id("moneyDock")).getAttribute("innerHTML"));
            double new_cargoInfo = Double.parseDouble(driver.findElement(By.id("cargoInfo")).getAttribute("innerHTML").split("/")[0]);

            // Проверки: ничего не изменилось
            assertEquals(new_price_buy, price_buy);
            assertEquals(new_price_sell, price_sell);
            assertEquals(new_on_board, on_board);
            assertEquals(new_in_port, in_port);
            assertEquals(new_cargoInfo, cargoInfo);
            assertEquals(new_cargoInfo, cargoInfo);
            assertEquals(new_money, money);
            assertEquals(new_moneyDock, moneyDock);

            waitButton(By.linkText("Вернуться в море")).click();
        } catch (AssertionFailedError ex) {
            waitButton(By.linkText("Вернуться в море")).click();
        } finally {
            // Logout
            WebElement logout = driver.findElement(By.id("logout"));
            if (logout != null)
                logout.click();
        }
    }

    // 1.3) Продажа не возможна
    // shopcnt-1 < item1cnt
    // Сценарий: логин, переход в док, попытка купить отрицательное число товара, проверка, что ничего не изменилось, выход из дока, логаут
    @Test
    public void countMoreDockCountSell() throws Exception {
        // Login
        driver.get("http://ruswizard.ddns.net:8091/");
        waitButton(By.xpath("//input[@value='Login']")).click();

        try {
            waitButton(By.linkText("Зайти в док")).click();

            // Получаем все значения
            double price_buy = Double.parseDouble(driver.findElement(By.id("item1buy")).getAttribute("value").split("\\[")[1].split("]")[0]);
            double price_sell = Double.parseDouble(driver.findElement(By.id("item1sell")).getAttribute("value").split("\\[")[1].split("]")[0]);
            double weight = Double.parseDouble(driver.findElement(By.id("widht-1")).getAttribute("innerHTML"));
            double in_port = Double.parseDouble(driver.findElement(By.id("dockcnt-1")).getAttribute("innerHTML"));
            double on_board = Double.parseDouble(driver.findElement(By.id("shopcnt-1")).getAttribute("innerHTML"));
            double money = Double.parseDouble(driver.findElement(By.id("money")).getAttribute("innerHTML"));
            double moneyDock = Double.parseDouble(driver.findElement(By.id("moneyDock")).getAttribute("innerHTML"));
            double cargoInfo = Double.parseDouble(driver.findElement(By.id("cargoInfo")).getAttribute("innerHTML").split("/")[0]);

            double count = in_port + 1;
            // Проверки, что остальные критерии покупки в норме
            assertTrue(price_buy > 0);
            assertTrue(money > price_buy * count);

            waitButton(By.id("item1cnt")).click();
            driver.findElement(By.id("item1cnt")).clear();
            driver.findElement(By.id("item1cnt")).sendKeys(Double.toString(count));

            waitButton(By.id("item1buy")).click();

            WebDriverWait wait = new WebDriverWait(driver, Duration.ofHours(1));
            wait.until(ExpectedConditions.attributeContains(By.id("status"), "innerHTML", "Online"));

            // Получаем все значения
            double new_price_buy = Double.parseDouble(driver.findElement(By.id("item1buy")).getAttribute("value").split("\\[")[1].split("]")[0]);
            double new_price_sell = Double.parseDouble(driver.findElement(By.id("item1sell")).getAttribute("value").split("\\[")[1].split("]")[0]);
            double new_weight = Double.parseDouble(driver.findElement(By.id("widht-1")).getAttribute("innerHTML"));
            double new_in_port = Double.parseDouble(driver.findElement(By.id("dockcnt-1")).getAttribute("innerHTML"));
            double new_on_board = Double.parseDouble(driver.findElement(By.id("shopcnt-1")).getAttribute("innerHTML"));
            double new_money = Double.parseDouble(driver.findElement(By.id("money")).getAttribute("innerHTML"));
            double new_moneyDock = Double.parseDouble(driver.findElement(By.id("moneyDock")).getAttribute("innerHTML"));
            double new_cargoInfo = Double.parseDouble(driver.findElement(By.id("cargoInfo")).getAttribute("innerHTML").split("/")[0]);

            // Проверки: ничего не изменилось
            assertEquals(new_price_buy, price_buy);
            assertEquals(new_price_sell, price_sell);
            assertEquals(new_on_board, on_board);
            assertEquals(new_in_port, in_port);
            assertEquals(new_cargoInfo, cargoInfo);
            assertEquals(new_cargoInfo, cargoInfo);
            assertEquals(new_money, money);
            assertEquals(new_moneyDock, moneyDock);

            waitButton(By.linkText("Вернуться в море")).click();
        } finally {
            // Logout
            WebElement logout = driver.findElement(By.id("logout"));
            if (logout != null)
                logout.click();
        }
    }

    //===========================================================
    // ВХОД В СЕССИЮ И ВЫХОД ИЗ НЕЕ
    @Test
    public void positiveLoginLogout() throws Exception {
        try {
            // Login
            driver.get("http://ruswizard.ddns.net:8091/");
            waitButton(By.xpath("//input[@value='Login']")).click();
        } finally {
            // Logout
            WebElement logout = driver.findElement(By.id("logout"));
            if (logout != null)
                logout.click();
        }
    }

    //===========================================================
    // Help methods
    private WebElement waitButton(By id) {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofHours(1));
        if (!id.equals(By.xpath("//input[@value='Login']"))) {
            wait.until(ExpectedConditions.attributeContains(By.id("status"), "innerHTML", "Online"));
        }
        return wait.until(ExpectedConditions.elementToBeClickable(id));
    }

    private void waitTimer() {
        WebElement elem = driver.findElement(By.id("timer"));

        while (elem != null && !elem.getText().trim().isEmpty()) {
            try {
                Thread.currentThread().join(1000);
                elem = driver.findElement(By.id("timer")); //element is changing from time to time
            } catch (InterruptedException e) {
            }
        }
    }

    @AfterClass(alwaysRun = true)
    public void tearDown() throws Exception {
        driver.quit();
        String verificationErrorString = verificationErrors.toString();
        if (!"".equals(verificationErrorString)) {
            fail(verificationErrorString);
        }
    }

    private boolean isElementPresent(By by) {
        try {
            driver.findElement(by);
            return true;
        } catch (NoSuchElementException e) {
            return false;
        }
    }

    private boolean isAlertPresent() {
        try {
            driver.switchTo().alert();
            return true;
        } catch (NoAlertPresentException e) {
            return false;
        }
    }

    private String closeAlertAndGetItsText() {
        try {
            Alert alert = driver.switchTo().alert();
            String alertText = alert.getText();
            if (acceptNextAlert) {
                alert.accept();
            } else {
                alert.dismiss();
            }
            return alertText;
        } finally {
            acceptNextAlert = true;
        }
    }
}